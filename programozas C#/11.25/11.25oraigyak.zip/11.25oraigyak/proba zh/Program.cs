﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace proba_zh
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Console.WriteLine(Eletkor(2003));
            //HackerIrasmod("Felénk mostanában nem értem mindek de esik az eső");
            Jatek();
        }

        static int Eletkor(int szulEv)
        { return 2025 - szulEv; }

        static void HackerIrasmod(string szoveg)
        {
            char[] atalakit = szoveg.ToCharArray();
            //l – 1, o – 0, e – 3, s – 5, ó – 6, t – 7, g - 9
            for (int i = 0; i < atalakit.Length; i++)
            {
                switch (atalakit[i])
                {
                    case 'l': atalakit[i] = '1'; break;
                    case 'o': atalakit[i] = '0'; break;
                    case 'e': atalakit[i] = '3'; break;
                    case 's': atalakit[i] = '5'; break;
                    case 'ó': atalakit[i] = '6'; break;
                    case 't': atalakit[i] = '7'; break;
                    case 'g': atalakit[i] = '9'; break;
                    default: break;
                }
            }
            Console.WriteLine(new string(atalakit));
        }

        //Fej vagy írás
        static char Beolvas()
        { char karakter;
            do {
                karakter = Console.ReadLine()[0];
                char.ToUpper(karakter);
            } while (karakter!='F' && karakter!='I');
            return karakter;
        }


        static void Jatek()
        { Random rnd = new Random();
            char[] lehetoseg = new char[] {'F', 'I'};
            int probalkozas = 0;

            char gondol, tipp;

            do
            {
                gondol = lehetoseg[rnd.Next(0,2)];
                Console.WriteLine("Gondoltam egy karakterre....");
                tipp = Beolvas();
                probalkozas++;

            } while (gondol.Equals(tipp) ); // gondool != tipp

            Eredmeny(gondol, probalkozas);
        }


        static void Eredmeny(char gondol, int probakozas)
        { Console.WriteLine($"Grat! A karakter: {gondol}"); 
         Console.WriteLine($"Grat! Ennyi próbálkozás volt: {probakozas}"); }





        }
    }
