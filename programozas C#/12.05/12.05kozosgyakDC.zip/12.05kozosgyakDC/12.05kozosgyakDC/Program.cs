﻿using System;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace _12._05kozosgyakDC
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Kepek(Beker());
            // Leghosszabb(Beker(3));


            //STRINGKEZELŐK
            string nev = "Tita";
            Console.WriteLine(nev.Equals("Tita"));

            char x = nev[nev.Length-1];
            Console.WriteLine(x);
            char y = nev[0];
            Console.WriteLine(y);
            Console.WriteLine("Kérek egy karakter: ");
            char a = Console.ReadLine()[0];
            Console.WriteLine(a);

            string nwv2 = "Tita";
            Console.WriteLine(nev.ToUpper());
            Console.WriteLine(nev.ToLower());
            string mondat = "Zolinak most nagyon faj a feje";
            int faj = mondat.IndexOf("faj");
            Console.WriteLine(faj);
            int db = 0;
            int szam = 0;
            while(true)
            { szam = mondat.ToLower().IndexOf("a", szam + 1);
                if (szam != -1)
                    db++;
                else break;
            }
            Console.WriteLine($"Ennyi darab 'a'- betű van a szövegben: {db}");
            string faj2 = mondat.Substring(faj);
            Console.WriteLine(faj2);

            mondat = mondat.Replace("nagyon", "nem");
            Console.WriteLine(mondat);

            string[] szetszed = mondat.Split(' ');
            foreach (string vmi in szetszed)
            { Console.WriteLine(vmi); }

            char[] karakterek = mondat.ToCharArray();
            foreach (char kkk in karakterek)
            {
                Console.Write(kkk);
            }

        }
        /*
        static string Beker()
        {   int pont;
            string fajlnev;
            int hossz;
            do
            {
                Console.WriteLine("Írja be a fájlt: ");
                fajlnev = Console.ReadLine().ToLower();
                pont = fajlnev.LastIndexOf('.');
                //ell
                //hossz = fajlnev.Length;
                //Console.WriteLine(pont);
                //Console.WriteLine(hossz);
            } while (fajlnev.Length - (pont+1) != 3);
            return fajlnev;
        }

        static void Kepek(string fajlnev)
        {
            int pont = fajlnev.LastIndexOf('.');
            string kiterjesztes = fajlnev.Substring(pont+1);
            Console.WriteLine(kiterjesztes);
            switch (kiterjesztes)
            { case "jpg": case "png": case "gif": Console.WriteLine("Kép típusu"); break;
                default: Console.WriteLine("Nem képtípusu a fájl"); break;
            }
                */
        /*
        static string[] Beker(int db)
        {
            string fajlnev;
            string[] tomb = new string[db];
            int pont;
            for (int i = 0; i < db; i++)
            {
                do
                {
                    Console.WriteLine("Írja be a fájlt: ");
                    fajlnev = Console.ReadLine().ToLower();
                    pont = fajlnev.LastIndexOf('.');
                    //ell
                } while (fajlnev.Length - (pont + 1) != 3);
                tomb[i] = fajlnev;
                //Console.WriteLine($"A string tömb {i+1} eleme: {tomb[i]}");

            }
            return tomb;

        }

        static void Leghosszabb(string[] tomb)
        {
            string leghosszabb = "";
            for (int i = 0; i < tomb.Length; i++)
            {
                if (tomb[i].Length > leghosszabb.Length)
                { leghosszabb = tomb[i]; }
            }

            Console.WriteLine($"A leghosszabb fájl neve: {leghosszabb}");
        }*/


    }




}
