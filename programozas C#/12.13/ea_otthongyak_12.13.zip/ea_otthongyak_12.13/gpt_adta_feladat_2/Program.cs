﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace gpt_adta_feladat_2
{
    public struct Verseny
    {
        public string jatekosNev;
        public byte forduloSzam;
        public int korosztaly;
        public double ido;
    }

    public struct Osszesit
    { public string jatekosNev;
        public double ido;
    }
   
    internal class Program
    {
        static int t = 0;
        static Verseny[] futok = new Verseny[40];
        static Osszesit[] minden = new Osszesit[40];

        static bool Beolvas()
        {
            try
            {
                StreamReader futoverseny_csv = new StreamReader("futoverseny.csv", Encoding.Default);
                while (!futoverseny_csv.EndOfStream)
                { string[] darabkak = futoverseny_csv.ReadLine().Split(';');
                    futok[t].jatekosNev = darabkak[0];
                    futok[t].forduloSzam = byte.Parse(darabkak[1]);
                    futok[t].korosztaly = int.Parse(darabkak[2]);
                    futok[t].ido = double.Parse(darabkak[3]);
                    t++;
                }
                futoverseny_csv.Close();
                Console.WriteLine("0.Feladat\nA fájlok beolvasása megtörtént");
                return true;
            } catch (Exception hiba)
            { Console.WriteLine("0.Feladat\nA fájlbeolvasás során hiba történt! " + hiba.Message);
                return false;
            }
        }
        static bool Kiir()
        {
            int z;
            int h = 0;
            bool kesz;
            for (int i = 0; i < t; i++)
            {
                kesz = false;
                for (z = 0; z < h; z++)
                { if (futok[i].jatekosNev == minden[z].jatekosNev)
                    { kesz = true; break; }
                }
                if (kesz)
                { minden[z].ido += futok[i].ido; }
                else { minden[h].jatekosNev = futok[i].jatekosNev;
                    minden[h].ido = futok[i].ido;
                    h++;
                }
            }

            try
            { StreamWriter jatekosok_txt = new StreamWriter("jatekosok.txt", false, Encoding.Default);
                for (z=0;z<h;z++)
                { jatekosok_txt.WriteLine(minden[z].jatekosNev +" " + Math.Round( minden[z].ido, 1) +"mp"); }
                jatekosok_txt.Close();
                Console.WriteLine("Az adatok kiírása megtörtént!");
                return true;
            } catch (Exception hiba)
            { Console.WriteLine(hiba.Message);
                return false;
            }
        }
        static void Main(string[] args)
        {
            if (Beolvas())
            {
                double ido = double.MaxValue;
                Verseny jobb = new Verseny();
                for (int i = 0; i < t; i++)
                {
                    if (futok[i].ido < ido)
                    {
                        ido = futok[i].ido;
                        jobb = futok[i];
                    }
                }
                Console.WriteLine($"1.feladat\nA leggyorsabb időt {jobb.jatekosNev} ért el a {jobb.forduloSzam}. fordulóban, korosztály: {jobb.korosztaly}, idő: {jobb.ido} mp.-vel");

                Console.WriteLine("Írja be egy játékos nevét: ");
                string kapottNev = Console.ReadLine().Trim();
                int db = 0;
                for (int i = 0; i < t; i++)
                {
                    if (kapottNev == futok[i].jatekosNev)
                        db++;
                }
                if (db != 0)
                    Console.WriteLine($"2.feladat\n{kapottNev} nevű játékos {db} fordulóban indult.");
                else Console.WriteLine("2.feladat\nIlyen nevű játékos nem indult a versenyen!");

                double kor14O = 0; int kor14db = 0;
                double kor12O = 0; int kor12db = 0;
                for (int i = 0; i < t; i++)
                {
                    if (futok[i].korosztaly == 14)
                    {
                        kor14db++;
                        kor14O += futok[i].ido;
                    }
                    else if (futok[i].korosztaly == 12)
                    {
                        kor12db++;
                        kor12O += futok[i].ido;
                    }
                }
                Console.WriteLine($"3.Feladat\n12 éves koorosztálynál az átlagidő: {Math.Round((double)kor12O / kor12db)} mp.");
                Console.WriteLine($"3.Feladat\n14 éves koorosztálynál az átlagidő: {Math.Round((double)kor14O / kor14db)} mp.");

                
            }
            else { Console.WriteLine("Viszlát!"); }
            Console.ReadKey();
        }
    }
}
