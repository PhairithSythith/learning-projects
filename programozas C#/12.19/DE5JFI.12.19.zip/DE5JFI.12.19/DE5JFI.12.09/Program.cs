﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace DE5JFI._12._09
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Vonatjegy();
            Diakjegy(true);
        }
        static double[] Vonatjegy()
        { Console.WriteLine("Írja be a kedvezményt: ");
            double kedvenmeny = Convert.ToInt32(Console.ReadLine().Trim());
            Console.WriteLine("Írja be a teljes árat: ");
            int teljesAr = Convert.ToInt32(Console.ReadLine().Trim());
            double[] arak = new double[2];
            double kedvar = teljesAr *(kedvenmeny%100);
            for (int i = 0; i < arak.Length; i++)
            {
                arak[0] = teljesAr;
                arak[1]= Convert.ToInt32( kedvar);
            }
            foreach (int a in arak)
            { Console.WriteLine(a); }
           
            return arak;
        }
        
        static void Diakjegy(bool ertek)
        { Random rnd = new Random();
            double jegyyar = rnd.Next(2000,4001);
            if (ertek = true)
                Console.WriteLine("90%-os " + ((jegyyar % 10) *90));
            else { Console.WriteLine("50%-os "+ jegyyar % 2); }
        }

    }

}
