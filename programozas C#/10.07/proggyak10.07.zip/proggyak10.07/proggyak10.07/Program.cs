﻿//For ciklus
/*for (int i = 1; i <= 10; i++)
{ Console.WriteLine(i); }
// a ciklusváltozó (i) csak a {} között használható
int i = 1;
for (; i <= 10;)
{ Console.WriteLine(i);
    i++;
}*/
//mivel az i a ciklus előtt lett létrehozva, itt is elérhteő

/*int i=1;
 * while(i<=10)
 * {console.writeline(i);
 * i++}
*/


//egyy sorban is megírható
//for (int i = 0; i < 20; i++, Console.WriteLine(i)) ;

//egymásba ágyazott ciklusok
/*for (int i = 1; i <= 10; i++)
{for (int j = 1; j <= 10; j++)
    {
        Console.WriteLine($"{i}*{j}={i*j}");
    }
    Console.WriteLine(); //rak egy új sort
}
*/
// a külső ciklus addig nem lép továb  amíg nem fut le minden a belsejében
//nem futott le minden a belsejében -> ciklus esetén  teljesen végig 

//kérj be 5 számot és írd ki az összegét
/*
int szam, osszeg = 0;
for (int i = 1; i <= 5; i++)
{
    Console.Write($"Kérem a(z) {i}. számot: ");
    szam = Convert.ToInt32(Console.ReadLine());
    osszeg= osszeg+ szam; 
}
Console.WriteLine($"A számok összege: {osszeg}");

int szam2=0, szorzat = 1;
for (int j = 1; j <= 5; j++)
{
    Console.WriteLine($"Kérem a(z) {j}. számot: ");
    szam2 = Convert.ToInt32(Console.ReadLine());
    szorzat = szam2 * szorzat;
}
Console.WriteLine($"A számok szorzata: {szorzat}");
*/
/* NEM JÓ MAJD JAVÍTSD
double szam3 = 0, atlag = 0, osszeg2=0;
for (int a = 1; a <= 5; a++)
{
        Console.WriteLine($"Kérem a(z) {a}. számot: ");
        szam3 = Convert.ToDouble(Console.ReadLine());
        osszeg2 = szam3 + osszeg;
        atlag = osszeg2 % szam3;
}

Console.WriteLine($"A számok átlaga: {atlag}");
*/

//készítünk egy példányt a random osztályból
/*Random rnd = new Random();
int szam = rnd.Next(0, 2);
Console.WriteLine(szam == ? "fej" : "írás" );
*/

Random rnd = new Random();

//generáljunk 10 és 200 között 10 db számot és írja ki ebből mennyi páros és páratlan
/*int szam, paros = 0, paratlan = 1, n = 0;
do{//generálunk számot 1 és 200 között
    szam = rnd.Next(1, 201);
    //páros e szám
    if (szam % 2 == 0) paros++; // növelem a páros változót
    else paratlan++; //növelem a páratlant
        n++;
} while (n<10 );
Console.WriteLine($"Páros db: {paros}, páratlan db: {paratlan}");
*/
//generálj 5 db páratlan számot 50 és 500 között
/*
int szam, db = 0, le=1;
do {
    szam = rnd.Next(50, 501);
    if (szam % 2 !=0 )
    {   Console.WriteLine(szam);
        db++; }
    le++;
}while (db < 5);
Console.WriteLine($"Ennyiszer futott le a ciklus: {le}");
*/
//írjunk egy játékor ahol a gép gondol egy számra 1-20 között és aa gép megmondja hogy eltalálta e vagy nem
/*
int gondol = rnd.Next(1, 21), db=0, tipp=0;

do
{
    Console.WriteLine("Melyik számra gondoltam (1-20)? ");
    tipp = Convert.ToInt32(Console.ReadLine());
    db++;
}while (tipp!= gondol);
Console.WriteLine($"Gratulálok! A gondolt szám: {gondol}" +
    $"a próbálkozások száma: {db}");
*/

/*
int lotto;
for (int i = 1; i <= 5; i++)
{
    lotto = rnd.Next(1, 91);
    Console.WriteLine(lotto); 
}
*/

int gondol = rnd.Next(1, 201);
int tipp, db = 0;
Console.WriteLine("Melyik számra gondoltam (1-200)?");
tipp = Convert.ToInt32(Console.ReadLine());

while(tipp != gondol)
{
    if (tipp< gondol) Console.WriteLine("A gondolt szám nagyobb");
    else Console.WriteLine("A gondolt szám kisebb");
    tipp = Convert.ToInt32(Console.ReadLine());
    db++;
}
Console.WriteLine($"Gratulálok! A gondolt szám: {gondol}" +
    $"a próbálkozások száma: {db}");

Console.ReadKey();
