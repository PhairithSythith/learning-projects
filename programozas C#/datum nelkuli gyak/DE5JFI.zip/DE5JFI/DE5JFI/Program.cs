﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DE5JFI
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //5-40 között random szám -> ez lesz a tömb hossza is
            Random rnd = new Random();
            int ellatmany = rnd.Next(5,41);
            int[] tomb = new int[ellatmany];
           
            
            //kérdezzük megg hány ember él a bolygón, ha kevesebb mint 1 akkor generáljunk 1-50 számot helyette
            //ha páros ember él 50-100 között legyenek az elemek ha páratlan 0-50 között
            int emberek = 0;
            int[] em = new int[emberek];
           Console.WriteLine("Hány ember él a bolygón? ");
           emberek = Convert.ToInt32(Console.ReadLine());
               for(int i=0;i<tomb.Length;i++)
                { if (emberek < 1)
                { emberek = rnd.Next(1, 51);}
                if (emberek % 2 == 0)
                {
                    tomb[i] = rnd.Next(51, 101);
                }
                if (emberek % 2 != 0)
                {
                    tomb[i] = rnd.Next(1, 51);
                }            
            }
            Console.WriteLine($"Tömb elemei: {string.Join(",", tomb)}");

            //összellátmány átlaga
           //int osszeg = (int)Math.Round((double)ellatmany+ellatmany/tomb.Length);
            Console.WriteLine($"Az összállomány átlaga: {tomb.Average()}");
            //a teljes készlet ennyi ideig elég
            int osszeg2 = ellatmany / emberek;
            Console.WriteLine($"Ennyi napra elegendő a teljes készlet a kolóniának: {osszeg2}");

            Console.WriteLine("Átlagosan elegendő - e a bolygó összes lakójának a napi ellátmány: ");
            if (osszeg2< 1)
            { Console.WriteLine("Nem elegendő"); }
            else
            { Console.WriteLine("Elegendő"); }
            int legtobbell = tomb.Max();
            Console.WriteLine($"A legtöbb ellátmánnyal rendelkező napon ha egy ember enné meg\n az egészet, ennyi napig lenne neki elég:{legtobbell/1} ");
            

        }
    }
}
