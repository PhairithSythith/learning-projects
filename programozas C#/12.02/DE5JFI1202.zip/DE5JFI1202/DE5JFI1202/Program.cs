﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace DE5JFI1202
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(Kepek());
            Console.ReadKey();
        }

        static string Beker()
        {
            string fajlNev;
            string fajlElso;
            string kiterj;
            do
            {   Console.WriteLine("Írjon be egy fájlnevet kiterjesztéssel együtt: ");
                fajlNev = Console.ReadLine().ToLower();
                int pont = '.';
                fajlElso = fajlNev.Substring(0, pont);
                kiterj = fajlNev.Substring(pont);
            } while (fajlNev.Contains(kiterj)); 

            return fajlNev;
        }

        static string Kepek()
        {   string fajlnev = Beker();
            int pont = '.';
            string kiterjt = fajlnev.Substring(pont);
            string kep = "Kép típusú fájl";
            string nokep = "Nem kép típusú fájl";
            string[] mondatok = {kep, nokep };
            string[] kiterj = {".jpg", ".png",".gif" };
            for (int i = 0; i < kiterj.Length; i++)
            { if (kiterj[i] == kiterjt)
                {
                    Console.WriteLine(kep);
                }
                else { Console.WriteLine(nokep); }
            }
            return kiterjt;
            
        }
        

    }
}
