﻿int szam;
do {
    Console.WriteLine("Válasszon egy számot 25 és 40 között: ");
    szam = Convert.ToInt32(Console.ReadLine());
} while (szam<=25 || szam>=40);
Random rnd = new Random();
szam = szam * rnd.Next(2,6);
int harmad = szam / 3;
int[] tomb = new int[harmad];
for (int i = 0; i < tomb.Length; i++)
{ tomb[i] = rnd.Next(-100,101); }
Console.WriteLine($"A tömb elemei:{string.Join(",",tomb)}");

double atlag =Math.Round( tomb.Average());
Console.WriteLine($"A tömb elemeinek átlaga: {atlag:F2}");

int veletlen = rnd.Next(0,tomb.Length);
int velem = tomb[veletlen];
Console.WriteLine($"Véletlenül kiválasztott elem: {velem}");


for (int i = 0; i < tomb.Length; i++)
{
    tomb[i] = tomb[i] + i * 2;
}
Console.WriteLine($"Minden szám a hozzáadott indexének 2x-vel:{string.Join(",",tomb)}" );

int osszeg = tomb.Sum();
Console.WriteLine($"A tömb elemeinek az összege: {osszeg}");

int neg = 0;
foreach (int n in tomb)
{ if (n < 0)
    { neg = neg + Math.Abs(n); } }
Console.WriteLine($"Ennyit kell hozzáadni hogy ne legyen negatív: {neg}");