﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Timers;

namespace ZhMegoldas
{
    internal class Program
    {
        static void Main(string[] args)
        {

            /*
             * 0.1.2.3.4.
             * 4-10-20-5-2
             * 
             * emberek:3 
             * fogyasztás: 2*3=6
             * a, átlag: 41 / 5= 8,2 ->round() 8
             * b, 41 / 6 = 6,83 -> 6 napra elég
             * c, 3
             * d, 8 / 6 = igen
             * e, max. 20 / 2 = 10 nap
              */ 

            Random rnd = new Random();
            int vel1 = rnd.Next(5,41);
            int[] ellatmany = new int[vel1];
            int ember = 0;

                Console.WriteLine("Hány ember él a bolygón? ");
                ember = Convert.ToInt32(Console.ReadLine());
            if (ember < 1)
            { ember = rnd.Next(1,51); }

           for (int i=0; i<ellatmany.Length;i++)
            { if (ember % 2 == 0)
                { ellatmany[i] = rnd.Next(51, 101); }
              else { ellatmany[i] = rnd.Next(1, 51); }
            }


            Console.WriteLine($"Ellátmányok száma: {string.Join(",", ellatmany)}");
            Console.WriteLine($"Ennyi ember él a bolygón: {ember}");

            //a.Számold ki az összellátmány átlagát, és kerekítsd egész számra a matematikai kerekítés szabályai szerint!
            int ossze = ellatmany.Sum();
            int atlag = (int)Math.Round((double)ossze / ellatmany.Length);
            Console.WriteLine($"Az összellátmány: {ossze}");
            Console.WriteLine($"Összellátmány átlaga: {atlag}");

            //b.
            int fogyasztas = ember * 2;
            Console.WriteLine($"A fogyasztás: {fogyasztas}");
            int eleg = (int)Math.Floor((double)ossze / fogyasztas);
            Console.WriteLine($"Ennyi napra elegendő a készlet a kolóniának: {eleg}");

            //c.
            int nemjut = 0;
            for (int i = 0; i < ellatmany.Length; i++)
                nemjut= ellatmany[i] / fogyasztas;
            { if (nemjut < 1)
                { Console.WriteLine($"Ennyi nap van amikor nem jut mindenkinek ellátmány:{nemjut} "); }
                else { Console.WriteLine("Ennyi nap van amikor nem jut mindenkinek ellátmány: Nincs ilyen nap"); };
            }

            //d.
            int elegendo = atlag / fogyasztas;
            if (elegendo >= 1)
            { Console.WriteLine("Átlagosan ELEGENDŐ a bolygó összes lakójának a napi ellátmány"); }
            else { Console.WriteLine("Átlagosan NEM ELEGENDő a bolygó összes lakójának a napi ellátmány"); };

            //e. 
            
            int LEGTOBBE = 0;
            /*
            foreach (int e in ellatmany)
            {
                if (LEGTOBBE < e)
                { LEGTOBBE = e; }
            }*/
            for (int i = 0; i < ellatmany.Length; i++)
            { if (ellatmany[i] > LEGTOBBE)
                    LEGTOBBE = ellatmany[i];
                        }
            Console.WriteLine($"A legtöbb ellátmánnyal rendelkező napon ha egy ember enné meg az egészet,\r\n ennyi napig lenne neki elég: {LEGTOBBE/2}");
            
        }

    }
}
