﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _12._08otthongyak
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //string fajlnev = BekerFajlnev();
            //Console.WriteLine(fajlnev);
            Kepek(BekerFajlnev());
        }

        static string BekerFajlnev()
        {
            string fajlnev;
            int pont;
            do
            {
                Console.WriteLine("Írja be a fájlnevet kiterjesztéssel: ");
                fajlnev = Console.ReadLine().Trim().ToLower();
                pont = fajlnev.LastIndexOf('.');
               if(fajlnev.Length - (pont + 1) != 3 || pont==-1) Console.WriteLine("Nem megfelelő a fájlnév! Próbálja újra!");
            } while (pont==-1 || fajlnev.Length - (pont + 1) != 3);
             
            return fajlnev;



        }

        static void Kepek(string fajlnev)
        {   int pont = fajlnev.LastIndexOf('.');
            string kiterjesztes = fajlnev.Substring(pont+1);
            switch (kiterjesztes)
            { case "jpg": case "png": case "gif": Console.WriteLine("Kép típusú fájl");break;
                default: Console.WriteLine("Nem kép tipusú fájl");break;
            }
        }
    }
}
