﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace gpt_adta_feladat_3
{
    public struct Kondi
    {
        public string KeresztNev, Tipus, Napszak;
        public int Sorszam, IdoTartam;
    }

    public struct Edzesszam
    {
        public string KeresztNev;
        public int DarabSzam;
    }
    internal class Program
    {
        static int z = 0;
        static Kondi[] kondizas = new Kondi[40];
        static Edzesszam[] oszzedz = new Edzesszam[40];

        static bool Beolvas()
        {
            try
            {
                StreamReader konditerem_csv = new StreamReader("konditerem.csv", Encoding.Default);
                while (!konditerem_csv.EndOfStream)
                {
                    string[] darab = konditerem_csv.ReadLine().Split(';');
                    kondizas[z].KeresztNev = darab[0];
                    kondizas[z].Sorszam = int.Parse( darab[1]);
                    kondizas[z].Tipus = darab[2];
                    kondizas[z].IdoTartam = int.Parse( darab[3]);
                    kondizas[z].Napszak = darab[4];
                    z++;
                }
                konditerem_csv.Close();
                Console.WriteLine("0.Feladat\nA fájlbeolvasás sikeres volt!");
                return true;

            } catch (Exception hiba)
            {
                Console.WriteLine("0.Feladat\nHiba történt fájlbeolvasás közben " + hiba.Message);
                return false;
            }
        }

        static bool Kiir()
        {
            int t;
            int u = 0;
            bool jo;
            for (int i = 0; i < z; i++)
            {
                jo = false;
                for (t = 0; t < u; t++)
                {
                    if (kondizas[i].KeresztNev == oszzedz[t].KeresztNev)
                    {
                        jo = true; oszzedz[t].DarabSzam++; break;
                    }
                }
                if (!jo)
                {
                    oszzedz[u].KeresztNev = kondizas[i].KeresztNev;
                    oszzedz[u].DarabSzam = 1;
                    u++;
                }
            }
            try
            {
                StreamWriter vendeg_txt = new StreamWriter("vendeg.txt", false, Encoding.GetEncoding(1250));
                for (t = 0; t < u; t++)
                {
                    vendeg_txt.WriteLine(oszzedz[t].KeresztNev +" "+ oszzedz[t].DarabSzam);
                }
                vendeg_txt.Close();
                Console.WriteLine("4.Feladat\nA fájlkiírás sikeres volt!");
                return true;
            }
            catch (Exception hiba)
            { Console.WriteLine("4.Feladat\nHiba történt fájlkiírás közben! "+hiba.Message);
                return false;
            }
        }

        static void Main(string[] args)
        {
            if (Beolvas())
            {
                int leghossz = int.MinValue;
                Kondi legtobb = new Kondi();
                for (int i = 0; i < z; i++)
                {
                    if (kondizas[i].IdoTartam > leghossz)
                    {
                        leghossz = kondizas[i].IdoTartam;
                        legtobb = kondizas[i];
                    }
                }
                Console.WriteLine($"1:Feladat\nA leghosszabb edzés: {legtobb.KeresztNev}, {legtobb.Sorszam}. edzés, {legtobb.IdoTartam} perc");

                Console.WriteLine("ÍRja be egy vendég  nevét: ");
                string KapNev = Console.ReadLine().Trim();
                int db = 0;
                int Osszperc = 0;
                for (int i = 0; i < z; i++)
                {
                    if (kondizas[i].KeresztNev == KapNev)
                    {
                        db++; Osszperc += kondizas[i].IdoTartam;
                    }
                }
                if (db != 0)
                {
                    Console.WriteLine($"2.Feladat\n{KapNev} nevű vendég {Osszperc} percet edzet.");
                }
                else
                {
                    Console.WriteLine("2.Feladat\nIlyen nevű vendég nem szerepel az adatokban!");
                }


                int kardDB = 0, kardOsz = 0;
                int sulyDB = 0, sulyOs = 0;
                for (int i = 0; i < z; i++)
                {
                    if (kondizas[i].Tipus == "kardio")
                    {
                        kardDB++; kardOsz += kondizas[i].IdoTartam;
                    }
                    if (kondizas[i].Tipus == "sulyzos")
                    {
                        sulyDB++; sulyOs += kondizas[i].IdoTartam;
                    }
                }
                Console.WriteLine($"3.Feladat\nA kardió edzések átlagos ideje: {Math.Round((double)kardOsz/kardDB)} perc\n" +
                    $"A sulyzós edzések átlaos ideje: {Math.Round((double)sulyOs/sulyDB)} perc");


            }
            if (Kiir())
            { }
            else
            {
                Console.WriteLine("Viszlát!");
            }
            Console.ReadKey();
        }
    }
}
