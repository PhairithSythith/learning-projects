﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.IO;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace ea_otthongyak_12._13
{
    public struct Eredmeny
    {
        public string nev, jatekTipus;
        public byte fordulo, asztal;
        public int nyeremeny;
    }
    public struct Jatekos
    {
        public string nev;
        public int nyeremeny;
    }

    internal class Program
    {
        static int n = 0;
        static Eredmeny[] eredmenyek = new Eredmeny[40];
        static Jatekos[] jatekos = new Jatekos[40];

        static bool Beolvas()
        {
            try
            {
                StreamReader poker_csv = new StreamReader("poker.csv", Encoding.Default);
                while (!poker_csv.EndOfStream)
                {
                    string[] szetszed = poker_csv.ReadLine().Split(';');
                    eredmenyek[n].nev = szetszed[0];
                    eredmenyek[n].fordulo = byte.Parse(szetszed[1]);
                    eredmenyek[n].asztal = byte.Parse(szetszed[2]);
                    eredmenyek[n].jatekTipus = szetszed[3];
                    eredmenyek[n].nyeremeny = int.Parse(szetszed[4]);
                    n++;
                }
                poker_csv.Close();
                Console.WriteLine("0.feladat\nAz adatok beolvasása megtörtént!");
                return true;
            }
            catch (Exception hiba)
            { Console.WriteLine("0.Feladat\nAz adatok beolvasása közben hiba történt.\n" + hiba.Message);
                return false;
            }
        }

        static bool Kiir()
        {
            int j;
            int z = 0;
            bool talalt;
            for (int i = 0; i < n; i++)
            {
                talalt = false;
                for (j = 0; j < z; j++)
                {
                    if (eredmenyek[i].nev == jatekos[j].nev)
                    { talalt = true;
                        break;
                    }
                }
                if (talalt)
                { jatekos[j].nyeremeny += eredmenyek[i].nyeremeny; }
                else
                { jatekos[z].nev = eredmenyek[i].nev;
                    jatekos[z].nyeremeny = eredmenyek[i].nyeremeny;
                    z++;
                }
            }
            try
            {
                StreamWriter jatekosok_txt = new StreamWriter("jatekosok.txt", false, Encoding.Default);
                for (j = 0; j < z; j++)
                {
                    jatekosok_txt.WriteLine($"{jatekos[j].nev};{jatekos[j].nyeremeny}");
                }
                jatekosok_txt.Close();
                return true;

            } catch (Exception hiba)
            {
                Console.WriteLine("A fájl írása közben hiba történt!" + hiba.Message);
                return false;
            }
        }
        static void Main(string[] args)
        {
            if (Beolvas())
            {
                int maxnyeremeny = int.MinValue;
                Eredmeny legjobbered = new Eredmeny();
                for (int i = 0; i < n; i++)
                {
                    if (eredmenyek[n].nyeremeny > maxnyeremeny)
                        legjobbered = eredmenyek[i];
                }
                Console.WriteLine($"1.feladat\nA legnagyobb nyereménye {legjobbered.nev}-nak/nek {legjobbered.fordulo}. fordúlban volt");

                Console.WriteLine("2.Feladat\nAdja meg egy játékos nevét: ");
                string kapottNev = Console.ReadLine().Trim();
                byte db = 0;
                for (int i = 0; i < n; i++)
                {
                    if (eredmenyek[i].nev == kapottNev)
                        db++;
                }
                if (db != 0)
                    Console.WriteLine($"{kapottNev} nevű játékos {db} fordulóban játszott");
                else Console.WriteLine("Ilyen nevű játékos nem volt a versenyen!");

                byte otlaposDB = 0, texasDB = 0;
                int otlaposossz = 0, texasossz = 0;
                for (int i = 0; i < n; i++)
                {
                    if (eredmenyek[i].jatekTipus == "Ötlapos póker")
                    {
                        otlaposDB++;
                        otlaposossz += eredmenyek[i].nyeremeny;
                    }
                    else if (eredmenyek[i].jatekTipus == "Texas Hold'Em")
                    {
                        texasDB++;
                        texasossz += eredmenyek[i].nyeremeny;
                    }
                }
                Console.WriteLine($"3.Feladat\nTexas Hold'em esetén az átlagos nyeremény: {Math.Round((double)texasossz / texasDB, 0)} FT\nÖtlapos póker esetén az átlagos nyeremény: {Math.Round((double)otlaposossz / otlaposDB, 0)} FT");

                Console.WriteLine("4.Feladat");
                if (Kiir())
                { Console.WriteLine("Az adatokat kiírtuk a jatekosok.txt állományba!"); }
                else Console.WriteLine("Sajnos a kiírás sikertelen!");
            }
            else Console.WriteLine("Viszonlátásra!");
            Console.ReadKey();
        }
    }
       
        
}

