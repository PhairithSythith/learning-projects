﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2DE5JFI1202
{
    internal class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
