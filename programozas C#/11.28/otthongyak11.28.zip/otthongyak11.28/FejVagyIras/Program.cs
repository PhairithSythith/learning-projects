﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace FejVagyIras
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Jatek();
        }
        static char Beolvas()
        {
            char karakter;
            do
            {
                
                karakter = Console.ReadLine()[0];
                char.ToUpper(karakter);

            } while (karakter != 'F' && karakter != 'I' && karakter != 'A' && karakter != 'B' && karakter != 'C' && karakter != 'D' && karakter != 'E' && karakter != 'G' && karakter != 'H'
            && karakter != 'P' && karakter != 'J' && karakter != 'K' && karakter != 'L' && karakter != 'M' && karakter != 'N' && karakter != 'O' && karakter != 'Q' && karakter != 'R' && karakter != 'S'
            && karakter != 'T' && karakter != 'V' && karakter != 'W' && karakter != 'X' && karakter != 'Y' && karakter != 'Z' && karakter != 'U');
           return karakter;
        }

        static void Jatek()
        { Random rnd = new Random();
            char[] jo = {'F','I','A','B','C','D','E','G','H','P','J','K','L','M','N','O','Q','R','S','T','V','W','X','Y','Z','U'};
            int probalkozas = 0;
            char gondol, tipp;
            do
            {
                gondol = jo[rnd.Next(0,26)];
                Console.WriteLine("Gondoltam egy karakterre...Tippeljen: ");
                tipp = Beolvas();
                probalkozas++;
            } while ( gondol != tipp);
            Eredmeny(gondol,probalkozas);
        }
        static void Eredmeny(char gondol, int probalkozas)
        { Console.WriteLine($"Gratulálok! {gondol} karakterre gondoltam és {probalkozas} db próbálkozásból jött rá!");  }

       
    }
}
