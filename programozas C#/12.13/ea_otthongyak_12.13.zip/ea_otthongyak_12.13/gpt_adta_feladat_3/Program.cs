﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace gpt_adta_feladat_3
{ public struct Labdarugas
    {
        public string JatekosNev, Csapat;
        public int golSzam, assziszt, JetekSZam;
    }

    public struct Ossz
    {
        public string JatekosNev;
        public int golSZam, assziszt;
    }
    internal class Program
    {
        static int z = 0;
        static Ossz[] kigyujtott = new Ossz[45];
        static Labdarugas[] focci = new Labdarugas[45];

        static bool Beolvas()
        {
            try
            {
                StreamReader foci_csv = new StreamReader("foci.csv", Encoding.UTF8);
                while (!foci_csv.EndOfStream)
                {
                    string line = foci_csv.ReadLine();
                   // Console.WriteLine($"DEBUG: read line = '{line}'");
                    string[] darab = line.Split(';');
                    //if (darab.Length < 5) { Console.WriteLine("DEBUG: rossz sor!"); continue; }
                    focci[z].JatekosNev = darab[0];
                    focci[z].Csapat = darab[1];
                    focci[z].golSzam = int.Parse(darab[2]);
                    focci[z].assziszt = int.Parse(darab[3]);
                    focci[z].JetekSZam = int.Parse(darab[4]);
                    z++;
                }
               // Console.WriteLine($"DEBUG: beolvasott sorok = {z}");
                foci_csv.Close();
                return true;
                Console.WriteLine("1.Feladat\nAz adatok beolvasása megtörtént!");
               return true;

            }
            catch (Exception hiba)
            {
                Console.WriteLine("1.Feladat\nAz adatok beolvasásása közben hiba történt. " + hiba.Message);
                if (z == 0)
                {
                    Console.WriteLine($"DEBUG: beolvasott sorok = {z}");
                }
                return false;
            }
            
        }
        static bool Kiir()
        {
            int b;
            int d = 0;
            bool jo;
            for (int i = 0; i < z; i++)
            {
                jo = false;
                for (b = 0; b < d; b++)
                { if (focci[i].JatekosNev == kigyujtott[b].JatekosNev)
                    { jo = true; break; }
                }
                if (jo)
                {
                    kigyujtott[b].golSZam = focci[i].golSzam;
                    kigyujtott[b].assziszt = focci[i].assziszt;
                }
                else 
                {
                    kigyujtott[d].JatekosNev = focci[i].JatekosNev;
                    kigyujtott[d].golSZam = focci[i].golSzam;
                    kigyujtott[d].assziszt = focci[i].assziszt;
                    d++;
                }
            }

            try
            {
                StreamWriter jatekosok_txt = new StreamWriter("jatekosok.txt", false, Encoding.Default);
                for (b = 0; b < d; b++)
                { jatekosok_txt.WriteLine(kigyujtott[b].JatekosNev+";"+ kigyujtott[b].golSZam + ";" + kigyujtott[b].assziszt); }
                jatekosok_txt.Close();
                return true;
            } catch (Exception hiba)
            { Console.WriteLine(hiba.Message);
                return false;
            }
        }

        
        static void Main(string[] args)
        {
            if (Beolvas())
            {
                int legtobb = int.MinValue;
                Labdarugas legjobb = new Labdarugas();
                for (int i = 0; i < z; i++)
                {
                    if (focci[i].golSzam > legtobb)
                    {
                        legtobb = focci[i].golSzam;
                        legjobb = focci[i];
                    }
                }
                Console.WriteLine($"2.Feladat\n{legjobb.JatekosNev} játékos {legjobb.JetekSZam} db mérkőzésen vett rész és {legjobb.golSzam} db gólt rugott. ");

                Console.WriteLine("Írja be egy játékos nevét: ");
                string Kapottnev = Console.ReadLine().Trim();
                bool kesz = false;
                int db = 0;
                for (int i = 0; i < z; i++)
                {
                    if (focci[i].JatekosNev == Kapottnev)
                    {
                        db = i;
                        kesz = true; ;
                    }
                }
                if (kesz)
                {
                    Console.WriteLine($"3.Feladat\n{Kapottnev} nevű játékos {focci[db].assziszt} asszisztolt és {focci[db].golSzam} gólt rúgott");
                }
                else { Console.WriteLine("3.Feladat\nIlyen nevű játékos nincs"); }

                int acbgO = 0, bfcgO = 0, cfcgO = 0;
                int acbgdb = 0, bfcgdb = 0, cfcgdb = 0;
                int acbaO = 0, bfcaO = 0, cfcaO = 0;
                int acbadb = 0, bfcadb = 0, cfcadb = 0;
                for (int i = 0; i < z; i++)
                {
                    if (focci[i].Csapat == "ACB")
                    {
                        acbgdb++; acbgO += focci[i].golSzam;
                        acbadb++; acbaO += focci[i].assziszt;
                    }
                    else if (focci[i].Csapat == "BFC")
                    {
                        bfcgdb++; bfcgO += focci[i].golSzam;
                        bfcadb++; bfcaO += focci[i].assziszt;
                    }
                    else if (focci[i].Csapat == "CFC")
                    {
                        cfcgdb++; cfcgO += focci[i].golSzam;
                        cfcadb++; cfcaO += focci[i].assziszt;
                    }
                }
                Console.WriteLine($"4.Feladat\nAz ACB csapat átlagosan {Math.Round((double)acbgO / acbgdb)} gólt rúgtak és átlagosan {Math.Round((double)acbaO / acbadb)} asszisztoltak");
                Console.WriteLine($"4.Feladat\nAz BFC csapat átlagosan {Math.Round((double)bfcgO / bfcgdb)} gólt rúgtak és átlagosan {Math.Round((double)bfcaO / bfcadb)} asszisztoltak");
                Console.WriteLine($"4.Feladat\nAz CFC csapat átlagosan {Math.Round((double)cfcgO / cfcgdb)} gólt rúgtak és átlagosan {Math.Round((double)cfcaO / cfcadb)} asszisztoltak");

            }
            if (Kiir())
            { Console.WriteLine("5.Feladat\nAz adatok kiírása megtörtént!"); }
            else { Console.WriteLine("Viszlát!"); }
            Console.ReadKey();
        }
    }
}
