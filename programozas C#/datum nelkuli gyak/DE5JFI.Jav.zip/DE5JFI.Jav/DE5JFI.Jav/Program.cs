﻿//1. két tört bekérése első tört 10-20 közötti másik 60-90 közötti legyen
using System.Reflection.Emit;

double tort1 = 0;
double tort2 = 0;
do
{
    Console.WriteLine("Adja meg az első tört számot 10-20 között: ");
    tort1 = Convert.ToDouble(Console.ReadLine());
} while (tort1<=10 || tort1>=20);
do
{
    Console.WriteLine("Adja meg a második tört számot 60-90 között: ");
    tort2 = Convert.ToDouble(Console.ReadLine());
} while (tort2<=60 || tort2>=90);

int tort1Ker = (int)Math.Floor((double)tort1);
int tort2Ker = (int)Math.Ceiling((double)tort2);
Random rnd = new Random();

// töltsük fel a tömböt véletlen számokkal, tömb hossza az első kerejített tört
double[] tomb = new double [tort1Ker];
for (int i=0;i<tomb.Length;i++)
{ tomb[i] = rnd.Next(1, 101); }


//páros számok kiiratása
int paros = 0;
foreach (int par in tomb)
{ if (par % 2 == 0)
        paros ++;
}
Console.WriteLine($"A tömben levő páros számok: {paros}");

Console.WriteLine($"A tömben levő elemek: {string.Join(",", tomb)}");

//kérjünk be 10-90 között számot ! csak azt fogadjuk el ami szerepel a tömben
double igeen = 0;
int szam = 0;
Console.WriteLine("Válasszon 10-90 között egy számot: ");
szam = Convert.ToInt32(Console.ReadLine());
foreach (int van in tomb)
{    if (van == szam)
    { Console.WriteLine("Szerepel a szám a tömben"); }
    else { Console.WriteLine("Próbálja újra! Válasszon egy számot 10-90 között: "); }
}

/*for (int i = 0; i < tomb.Length; i++)
{
    igeen = tomb[i];
    do
    { Console.WriteLine("Válasszon egy egész számot 10-90 között: ");
      szam = Convert.ToInt32(Console.ReadLine());
    } while (szam <= 10 || szam >= 90 );
}
*/

//írjuk ki az elemeket úgy hogy mindenből levon 0,1-et
double kivon = 0;
double[] ujElemek = new double[tomb.Length];
for (int i=0;i<tomb.Length;i++)
{ ujElemek[i] = tomb[i]- 0.1; }
Console.WriteLine($"A tömb elemei a 0.1-es kivonás után: {string.Join(",", ujElemek)}");


//páros vagy ypáratlan számok vannak többen?
int paros2 = 0;
int paratlan = 0;
foreach (int par in ujElemek)
{ if (par % 2 == 0)
    { paros2++; }
    if (par % 2 == 1)
    { paratlan++; }
    }
if (paros2 > paratlan)
    Console.WriteLine("A páros számok vannak többen");
else { Console.WriteLine("A páratlan számok vannak többen"); }

//MENNYI A 20-40 KÖZÖTTI SZÁMOK ÁTLAGA
double db = 0;
double ossz = 0;
foreach (int sz in ujElemek)
{ if (sz <= 20 || sz >= 40)
     ossz+=sz;
    db++;
}
Console.WriteLine($" 20-40 közötti számok összege: {ossz}");
double atlag = ossz / db;
Console.WriteLine($"A 20 és 40 közötti számok átlaga: {atlag}");
