﻿//tömbök <-előre kéri a változók (elemek) számát /dinamikusan nem növelhető (a program futása közben) inkább legyen nagyobb
// 0-tól indexelünk (onnan indul!) NEM! 1-től!!!!!!!!
//ciklusokkal nagyon jó
//foreach ciklus (tömb bejáró ciklus)

// NULL  érték - érték hiányát jelenti szóval nem 0 és nem egyenlő az üres stringgel (' ') sem!

//string haverok = null;
//Console.WriteLine(haverok==null);

//Null pointer Exception- hibaüzenet
//haverok.ToLower();

//?- felveheti a változó a null értéket is
//haverok?.ToLower(); //nincs így hibaüzenet

//típus[] és név = new típus[tömb hossza]
//string[] haverok= new string[3]; //3 elemű string tömb
// van 0.-ik 1. és 2. eleme =3 elem össz.
//írjuk ki a haverok 0. indexű elemet
//ez egy üres tömb így minden eleme null érték
//Console.WriteLine(haverok[0]);
//console.writwlinw(haverok==null);

//int -> 18 elemű pontok tömb
//int[] pontok = new int[18];
//int esetén minden tömb eleme alapértelmezetten 0 értéket kap
//Console.WriteLine(pontok[0]);
//bool esetén: false, double-float esetén:0,0
//bool [] igazak= new bool[5];


//olyan elemre hivatkozás ami nem létezik 
//IndexOutOfExpectio- olyan indexre hivatkoztál ami nem létezik (hiba üzenet)
//Console.WriteLine(haverok[3]);

//hány eleme van a tömbnek?
//Lenght nem 0-tól számol, a tömb elemeinek a számat adja meg
//Console.WriteLine(haverok.Length);

//honnan tudjuk meg mi a tömb utolsó eleme (minden tömbnél működik!)
//int utolsoIdx = haverok.Length - 1;
//Console.WriteLine(haverok[utolsoIdx]); //megkapom az utolsó elemet

//tömb elemeinek feltöltése
//haverok[0] = "Pati";
//haverok[2] = "Dani";

//shortcut: tömb literál (array literal)
//string[] haverok = { "Zoli", "Pati", "Dani" };
/*string[] haverok;
haverok = new string[] { "Zoli", "Pati", "Dani" };
//küldjünk üzit a bariknak
/*foreach (string barat in haverok) 
{
    Console.WriteLine($"Hali {barat} haver , a film 7-kor kezdődik, tali ott!");
} */

//2 vagy több dimenziós tömb -> [][] 2 dimenzió [] a dimenziót adja meg
/*int[][] pontszamok = {
new int[]{ 1, 2, 4, 2, 6, 5, 4, 3, 3, 2, 5, 7, 2, 7, 8, 4, 3, 2 },
new int[]{ 2, 3, 5, 1, 1, 2, 3, 1, 1, 2, 4, 1, 3, 3, 2, 6, 3, 2 },
new int[] {4, 4, 2, 1, 2, 2, 1, 4, 2, 2, 2, 3, 2, 5, 8, 1, 2, 2}
};
Console.WriteLine(pontszamok[1][2]);

for (int I = 0; I < pontszamok.Length; I++)
{ Console.WriteLine(haverok[I]);
    Console.WriteLine("-----------");
    for (int j = 0; j < pontszamok[I].Length; j++)
    { Console.WriteLine($"#{j+1} lyuk pontszám: {pontszamok[I][j]}"); };
    Console.WriteLine();
}*/
//tömbkezelő függvények

//sort- rendezés növekvő sorrendben
//int[] szamok = { 5, 2, 3, 4, 9 };
//Array.Sort(szamok); //-sorrba rendezi
//Array.Reverse(szamok); //-megfordítja az elemeket

//foreach (int sz in szamok)
//{ Console.WriteLine(sz); }

//indexof -keresés index alapján
//ha nincs benne -1 értéket ad vissza (nincs nem létezik)
//int idx = Array.IndexOf(szamok, 2); //hányadik indexen található
//Console.WriteLine(idx);  //1. az indexe, azon van

//contains (exists) - tartalmaz-e, benne van-e
/*bool van = Array.Exists(szamok, n => n == 2); //== helyett lehet logiaki kifejezést is használni
Console.WriteLine(van);

//max és min kiválasztás
int max = szamok.Max();
int min = szamok.Min();
Console.WriteLine($"A legnagyobb elem: {max}, a legkisebb: {min}");


//összeg és átlag
int osszeg = szamok.Sum();
double atlag = szamok.Average();
Console.WriteLine($"A számok összege: {osszeg}, a számok átlaga:{atlag}" );*/

//Töltsük fel egy 10 elemű tömböt 1 és 50 közötti számmla
//írjuk ki a párosokat zölddel, a páratlanokat pirossal
//1. legyen tömb
/*using System.ComponentModel.Design;

int[] szamok = new int[10];
//készítsünk obijektumot
Random rnd = new Random();
//foreach ciklussal nem tudsz tömböt feltölteni vagy változtatni
for (int i = 0; i < szamok.Length; i++)
{
    szamok[i] = rnd.Next(1, 51);
}
//4. írjuk ki a számokat
foreach (int sz in szamok)
{ //páratlan vagy páros
    if (sz % 2 == 0) { Console.ForegroundColor = ConsoleColor.Green; }
    else Console.ForegroundColor = ConsoleColor.Red;
    Console.Write($"{sz}, ");
}
//ha nem állítod vissza a szöveg színes marad

Console.ForegroundColor = ConsoleColor.White;*/

//generálj lottó számokat 1-90, tárold el 5 elemű tömbben, egy szám csak 1x lehet és növekvő sorrban leet kiírni

int[] lotto = new int[5];
Random rnd = new Random();
int szam, db=0;
for (int i = 0; i < lotto.Length;)
{
    szam = rnd.Next(1, 91);
    if (Array.IndexOf(lotto, szam) == -1)
    { lotto[i] = szam;
        i++;
    }
    db++;
}
Array.Sort(lotto);
foreach (int sz in lotto)
{
    Console.WriteLine($"{sz}, ");
}
Console.WriteLine(db);

Console.ReadKey();