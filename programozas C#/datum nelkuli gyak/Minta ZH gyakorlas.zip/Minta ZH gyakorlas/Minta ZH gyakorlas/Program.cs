﻿
//1. szám bekérés 25- 40 közt 
int szam;
do
{
    Console.WriteLine("Válasszon egy számot 25 és 40 között: ");
    szam = Convert.ToInt32(Console.ReadLine());

} while (szam<=25 || szam>=40);
//2. 2-5 közötti számmal megszorzása a bekért számnak
Random rnd = new Random();
szam = szam * rnd.Next(2,6);
//3. tömb ami a kapott szám harmada hosszú legyen, töltsük fel a tömböt -100 és 100 közötti számokkal
int harmad  = (int)Math.Round((double) szam/3);
int[] szamok = new int[harmad];
for (int i = 0; i < szamok.Length; i++) 
{ szamok[i] = rnd.Next(-100, 101); }
//4. Írjuk ki az elemek átlagát
Console.WriteLine($"Számok átlaga:{szamok.Average()}");
//5. random válasszon ki egy elemet index alapján a tömbből
int veletlenszam = rnd.Next(0,szamok.Length);
int elem = szamok[veletlenszam];
Console.WriteLine($"Véletlenszerűen kiválasztott elem indexe: {veletlenszam}");
//6. minden számhoz adjuk hozzá a tömbindexének a 2x
for (int i = 0; i < szamok.Length; i++)
{ szamok[i] = szamok[i] + i * 2; }
// ne legyen benne negatív
int negativ=0;
foreach (int sz in szamok)
{ if (sz < 0) ;
    { negativ = negativ + Math.Abs(sz); }   }

Console.WriteLine($"ENnyit kell hozzá adni hogy ne legyen negatív: {negativ}");


Console.ReadKey();