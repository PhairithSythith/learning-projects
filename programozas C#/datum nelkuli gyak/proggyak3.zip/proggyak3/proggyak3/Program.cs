﻿
//Console.WriteLine("Kérem írja be a nevét: ");
//string nev = Console.ReadLine();
/*
int szam;
do
{
    Console.WriteLine($"{nev} válasszon egy számot: ");
    szam = Convert.ToInt32(Console.ReadLine());
    Console.WriteLine($"A beírt szám: {szam}");
} while (szam != 0);
/*
/*
int szam = 0, db = 0;
do
{
    Console.WriteLine($"{nev} írjon be számot: ");
    szam += Convert.ToInt32(Console.ReadLine());
    db++;
}
while (db < 5);
Console.WriteLine("A számok átlaga: " +szam/db);
*/
/*
int szam = 0, max = 0;
do
{
    Console.WriteLine($"Válasszon egy számot: ");
    szam = Convert.ToInt32(Console.ReadLine());
    if (szam > max) max = szam;
} while (szam != 0 );
Console.WriteLine("A legnagyobb szám:" +max);
*/
/*
int szam = 0;
do
{
    Console.WriteLine($"{nev} válasszon egy számot: ");
    szam = Convert.ToInt32(Console.ReadLine());
} while (szam < 1 || szam > 7);

switch (szam)
    { case 1: case 2: case 3: case 4: case 5: Console.WriteLine("Hétköznap"); break;
    case 6: case 7: Console.WriteLine("Hétvége"); break; }
*/
/*
int szam = 0;
do
{
    Console.WriteLine($"Válasszon egy számot {nev}: ");
    szam += Convert.ToInt32(Console.ReadLine());
    Console.WriteLine("Az eddigi összeg:" +szam);
} while (szam<100);
Console.WriteLine("A számok összege:" + szam);
*/

/*
 Console.WriteLine($"{nev} válasszon egy számot: ");
 int szam = Convert.ToInt32(Console.ReadLine());
do
{
    Console.WriteLine("xo");
    szam--;
} while (szam > 0);
*/
/*
Console.WriteLine($"{nev} válasszon egy számot: ");
int szam = Convert.ToInt32(Console.ReadLine());
do
{
    Console.WriteLine(szam);
    szam--;
} while (szam > 0);
*/
/*
int szam = 0, osszeg = 0;
do
{
    Console.WriteLine($"Válasszon {nev} egy páros számot:");
    szam = Convert.ToInt32(Console.ReadLine());
    if (szam % 2 == 0 && szam != 0) osszeg += szam;
} while (szam !=0 && szam%2!=0);
Console.WriteLine("A bekért számok összege:"+osszeg);
*/
/*
int n = 1, szam = 1;
do
{
    Console.WriteLine($"Kérem a(z) {n} számot:");
    szam *= Convert.ToInt32(Console.ReadLine());
    n++;
} while (n <6);
Console.WriteLine("A szám szorzata:"+szam);
*/
/*
int szam = 0;
do
{
    Console.WriteLine("Kérek egy számot");
    szam = Convert.ToInt32(Console.ReadLine());
    Console.WriteLine("A választott szám"+szam);
} while (szam > 0);
*/
/*
int szam = 0, db = 0;
do
{
    Console.WriteLine("válasszon egy számot:");
    szam += Convert.ToInt32(Console.ReadLine());
    db++;
} while (db < 5);
Console.WriteLine("A számok átlaga: "+szam/db);
*/
/*
int szam = 0, legnagyobb = 0;
do
{
    Console.WriteLine("Válasszon egy számot:");
    szam = Convert.ToInt32(Console.ReadLine());
    if (szam> legnagyobb) legnagyobb=szam;
} while (szam != 0);
Console.WriteLine("A legnagyobb szám:" + legnagyobb);
*/
/*
int szam = 0;
do
{
    Console.WriteLine("Válasszon egy számot:");
    szam = Convert.ToInt32(Console.ReadLine());
} while (szam < 1 || szam > 7);
switch (szam)
    { case 1: case 2: case 3: case 4: case 5: Console.WriteLine("Hétköznap"); break;
    case 6: case 7: Console.WriteLine("Hétvége"); break; }
*/


