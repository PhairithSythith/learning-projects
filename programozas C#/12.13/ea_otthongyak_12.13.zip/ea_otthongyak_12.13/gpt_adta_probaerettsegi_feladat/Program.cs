﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace gpt_adta_probaerettsegi_feladat
{
    public struct Verseny
    {
        public string TanuloNev, TanTargy;
        public int PontSzam;
    }

    public struct Tanulok
    {
        public string TanuloNeve;
        public int PontSzam;
    }

    internal class Program
    {
        static int t = 0;
        static Verseny[] versenyzok = new Verseny[100];
        static Tanulok[] tanollok = new Tanulok[100];

        static bool Beolvas()
        {
            try
            {
                StreamReader verseny_csv = new StreamReader("verseny.txt", Encoding.UTF8);
                while (!verseny_csv.EndOfStream)
                {
                    string[] darab = verseny_csv.ReadLine().Split(';');
                    versenyzok[t].TanuloNev = darab[0];
                    versenyzok[t].TanTargy = darab[1];
                    versenyzok[t].PontSzam = int.Parse(darab[2]);
                    t++;
                }
                verseny_csv.Close();
                Console.WriteLine("0.Feladat\nAz adatok beolvasásaa megtörtént!");
                return true;

            }
            catch (Exception HIBA)
            {
                Console.WriteLine("0.Feladat\nHiba történt az adatok beolvasása közben! " + HIBA.Message);
                return false;
            }
        }

        static bool Kiir()
        {
            int u;
            int g = 0;
            bool megvan;
            for (int i = 0; i < t; i++)
            {
                megvan = false;
                for (u = 0; u < g; u++)
                {
                    if (tanollok[u].TanuloNeve == versenyzok[i].TanuloNev)
                    { megvan = true; break; }
                }
                if (megvan)
                { tanollok[u].PontSzam += versenyzok[i].PontSzam; }
                else
                {
                    tanollok[g].TanuloNeve = versenyzok[i].TanuloNev;
                    tanollok[g].PontSzam = versenyzok[i].PontSzam;
                    g++;
                }
            }

            try
            {
                StreamWriter tanulok_txt = new StreamWriter("tanulok.txt", false, Encoding.Default);
                for (u = 0; u < g; u++)
                { tanulok_txt.WriteLine(tanollok[u].TanuloNeve + ";" + tanollok[u].PontSzam); }
                tanulok_txt.Close();
                Console.WriteLine("4.Feladat\nAz adatok kiírása megtörtént!");
                return true;
            }
            catch (Exception hiba)
            {
                Console.WriteLine("4.Feladat\nA fájl kiírása közben hiba történt! " + hiba.Message);
                return false;
            }
        }


        static void Main(string[] args)
        {
            if (Beolvas())
            {
                int legnagyobb = int.MinValue;
                Verseny legjobb = new Verseny();
                for (int i = 0; i < t; i++)
                {
                    if (versenyzok[i].PontSzam > legnagyobb)
                    {
                        legnagyobb = versenyzok[i].PontSzam;
                        legjobb = versenyzok[i];
                    }
                }
                Console.WriteLine($"1.Feladat\nA lemagasabb pontszámot {legjobb.TanuloNev} érte el {legjobb.TanTargy} tantárgyból {legjobb.PontSzam} ponttal.");

                Console.WriteLine("Írja be egy tanuló nevét: ");
                string kapottNev = Console.ReadLine();
                int db = 0;
                for (int i = 0; i < t; i++)
                {
                    if (versenyzok[i].TanuloNev == kapottNev)
                    { db++; }
                }
                if (db != 0)
                    Console.WriteLine($"2.Feladat\n{kapottNev} tanuló {db} szerepelt a versenyen");
                else { Console.WriteLine($"2.Feladat\n{kapottNev} név nem szerepel a versenyen."); }

                int matekdb = 0, matekO = 0;
                int fizikadb = 0, fizikaO = 0;
                int biologiadb = 0, biologia0 = 0;
                for (int i = 0; i < t; i++)
                {
                    if (versenyzok[i].TanTargy == "Mate")
                    {
                        matekdb++; matekO += versenyzok[i].PontSzam;
                    }
                    if (versenyzok[i].TanTargy == "Biológia")
                    { biologiadb++; biologia0 += versenyzok[i].PontSzam; }
                    if (versenyzok[i].TanTargy == "Fizika")
                    { fizikadb++; fizikaO += versenyzok[i].PontSzam; }
                }
                Console.WriteLine($"3.Feladat\nMatek átlag: {Math.Round((double)matekO / matekdb)}");
                Console.WriteLine($"3.Feladat\nBiológia átlag: {Math.Round((double)biologia0 / biologiadb)}");
                Console.WriteLine($"3.Feladat\nFizika átlag: {Math.Round((double)fizikaO / fizikadb)}");

                double matlag = Math.Round((double)matekO / matekdb);
                double fatlag = Math.Round((double)biologia0 / biologiadb);
                double batlag = Math.Round((double)fizikaO / fizikadb);
                List<string> atlagfelett = new List<string>();

                for (int i = 0; i < t; i++)
                {
                    double targyAtlag = 0;
                    if (versenyzok[i].TanTargy == "Mate") targyAtlag = matlag;
                    if (versenyzok[i].TanTargy == "Fizika") targyAtlag = batlag;
                    if (versenyzok[i].TanTargy == "Biológia") targyAtlag = fatlag;

                    if (versenyzok[i].PontSzam > targyAtlag)
                        atlagfelett.Add(versenyzok[i].TanuloNev);
                }

                Console.WriteLine("Átlag felett teljesítettek: " + string.Join(", ", atlagfelett.Distinct()));


                if (Kiir()) ;
                else { Console.WriteLine("Viszlát!"); }
                Console.ReadKey();
            }
        }
    }
}
