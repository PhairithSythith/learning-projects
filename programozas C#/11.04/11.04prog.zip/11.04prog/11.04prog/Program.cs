﻿//REGEK (regular expressions) minden nyelvben benne van
//TAJ: 000-000-000

/* !!!!!!!!!!!!!!!!!!!!!!!
 . -bármely karakter
? -valami 0x vagy 1x fordulhat elő
* -valami 0x vagy többször fordul elő
+ -valami 1x vagy többször fordul elő
{} -intervallum - valami hánszor forduljon elő
                -{3} - 3x ismétlődik, {2, } -2x vagy többször ismétlődik
                -{2,5} - 2x, 3x, 4x, vagy 5x ismétlődhet
\d -digit, számjegy 0-9
\w -karakter (szöveges vagy szám)
^ -megadjuk a mintázat elejét
$ -megadjuk a mintázat végét
!!!!!!!!!!!!!!!!!!!!!!! */

using System.Text.RegularExpressions;
using System.Threading.Channels;

//string regex = "^.{5}$"; //enélkül is lehet de akkor a zárójelbe kell beleírni
//string regex = "^\\d{4}$";
//string regex = "^\\(\\d\\d\\) \\d{3}\\-\\d{3}$";   telefonszám pl
//string regex = "^\\d{3}\\-\\d{3}\\-\\d\\d\\d$";    TAJ pl
//string regex = "^\\d{6}[A-Z][A-Z]$";  //kisbetűnagybetű [A-Za-z], ékezet [A-ZÁŐÉÍ]
//string regex = "^\\((20|30|40|50)\\) \\d{3}\\-\\d{4}$";

//Regex r = new Regex(@regex); //@ kell mindig bele

//bool illeszkedik = r.IsMatch("(20) 554-3615");
//Console.WriteLine(illeszkedik);

// HÁZI SZEMÉLYNÉVRE ÍRJ REGEXET
// MIN: 7 KARAKTER :KIS ÉVA
// MINDEN NÉV KEZDŐ KARAKTERE NAGYBETŰ LEGYEN
// LEHESSEN OPCIONÁLIS A MÁSODIK KERESZTNÉV MEGADÁSA



//stringkezelő függvények

//1. Equals() - 2 string azonsoságát vizsgálja
/*string nev = "Tita";
Console.WriteLine(nev.Equals("Titta"));*/

//2. stringből kibontás egy adott karaktert
string mondat = "Finom az alma, ami Anett fenekéből potyog";
/*char x = mondat[0]; //visszatér az 1. karakterrel a mondatból
//char x = mondat[mondat.Length-1]; //visszatér az utolsó karakterre a mondatból

Console.WriteLine(x);*/

//3. egy db karaktert olvasol be  a konzolról
/*Console.WriteLine("Kérek egy karaktert: ");
char a = Console.ReadLine()[0];
Console.WriteLine($"A bekért karakter:{a}");*/

//4. csupa nagybetű csupa kisbetű
/*string polo = "xxl";
Console.WriteLine(polo.ToUpper()); //kicsi: polo.ToLower()*/

//5. karakterpoziciónak megkeresése szövegben
/*int alma = mondat.IndexOf("alma");
Console.WriteLine($"Az alma:{alma}"); // ha nincs benne a mondatban a keresett szó akkor -1, ha többször benne van akkor az első előfordulást mutatja*/

// számoljuk meg a mondatban az a betűket
/*int db = 0;
int szam = -1; // azért -1 hogy az első előfordulás 0 indexen legyen

while (true)
    //2. argumentum hanyadik indexétől keresse
{ szam = mondat.ToLower().IndexOf("a", szam+1);
    if (szam != -1) db++; //ha találat van akkor növeli a db számot
    else break; //kilép a ciklusból ha nincs benne
}
Console.WriteLine(db);*/

//6. szövegrész kivágása strinből
//2. argumentum nem kötelező
// Substring(kezdőindex, kivágandó szöveg hossza);
/*int alma = mondat.LastIndexOf("alma");
//kivágom az alma szót a mondatból
string kivag = mondat.Substring(alma,4); // ha nincs hossz (4) akkor a keresett szótól az egész szöveget vissza adja
Console.WriteLine(kivag);*/

//7. felesleges whitespacek törlése
//user: boglarka23
/*string user = " boglarka23 ";
Console.WriteLine(user.Trim().Length);*/

//8. Szövegrész cserélése stringben 
// Replace(mit, mire);
/*mondat = mondat.Replace("alma", "körte");
Console.WriteLine(mondat);*/

//9. üres string ellenőrzése
// üres string: nincs benne érték ""
//Console.WriteLine(string.IsNullOrEmpty(""));

//10. stringtömbökké felbontása a stringeknek
/*string pelda = "Szittya magyar az én szomszédom";
//delimiter : mi alapján bontsa fel a stringet (itt szóköz alapján)
string[] mondatom = pelda.Split(" ");

foreach (string sz in mondatom)
{ Console.WriteLine(sz); } */

//11. string felbontása karakter tömbbé
/*char[] karakterek = mondat.ToCharArray();
foreach (char sz in karakterek)
{ Console.Write(sz + ", "); }*/

//számold meg hányszor szerepel az "e" betű a mondatban
/* szoveg = Console.ReadLine();

int db = 0; //hány db karakter van
foreach (char e in szoveg.ToLower())
{ if (e == 'e') db++; }
Console.WriteLine($"Ennyi 'e' betű van: {db}");*/

//kérj be egy mondatot a "rossz" szót cseréld "jó"ra

/*Console.WriteLine("Írjon be egy mondatot: ");
string szoveg = Console.ReadLine();
string uj = szoveg.Replace("rossz", "jó");
Console.WriteLine(uj);*/


//kérj be egy szöveget majd írd ki hogy hány karakter kellen még hogy 50 karakter legyen illetve hogy páros vagy páratlan a karakterek száma
/*Console.WriteLine("Kérek egy szöveget: ");
string szoveg = Console.ReadLine();
int hiany = 50 - szoveg.Length;
Console.WriteLine($"Még {hiany} karakter kell az 50-hez.");
if (szoveg.Length % 2 == 0)
    Console.WriteLine("pÁROS");
else
    Console.WriteLine("pÁRATLAN");*/

//alakíts át egy email címet a kövekező formátumra 
//aladar[kukac]webcimem[pont]hu
/*
 * NEM JÓ!!!!!!!!
 * string regex= "^\\w{1,10}\\@\\w{1,10}\\.\\w{2}$";

Regex r = new Regex(@regex);
bool jo = r.IsMatch("titanilla@webcim.hu");

Console.WriteLine(jo);*/
string email = "labamkozottvanegy@gmail.com";
int kukac = email.IndexOf("@");
int pont = email.LastIndexOf(".");
Console.WriteLine(email.Substring(0, kukac) +
    "[kukac]" +
    email.Substring(kukac + 1, pont - kukac - 1) +
    "[pont]" +
    email.Substring(pont + 1));

//vmi neptunkódos feladat
string abc = "abcdefghijklmnopqrstuwxyz0123456789";
int szam;
string neptun = "";
Random rnd = new Random();
for (int i = 0; i < 7; i++)
{ szam = rnd.Next(0, abc.Length);
    neptun += abc[szam];
}
neptun += ".SZE";
Console.WriteLine(neptun.ToUpper());





Console.ReadKey();