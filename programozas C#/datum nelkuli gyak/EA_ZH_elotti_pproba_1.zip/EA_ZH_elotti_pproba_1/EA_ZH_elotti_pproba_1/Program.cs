﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EA_ZH_elotti_pproba_1
{
    public struct Eredmenyek
    {
        public string Nev, Tipus;
        public int Asztalszam, Forduloszam, Nyeremeny;
    }

    public struct Vegso
    {
        public string Nev;
        public int Nyeremeny;
    }

    internal class Program
    {
        static int z = 0;
        static Eredmenyek[] eredmeny = new Eredmenyek[40];
        static Vegso[] ossz = new Vegso[40];

        static bool Beolvas()
        {
            try
            {
                StreamReader poker_csv = new StreamReader("poker.csv", Encoding.Default);
                while (!poker_csv.EndOfStream)
                {
                    string[] darab = poker_csv.ReadLine().Split(';');
                    eredmeny[z].Nev = darab[0];
                    eredmeny[z].Forduloszam = int.Parse(darab[1]);
                    eredmeny[z].Asztalszam = int.Parse(darab[2]);
                    eredmeny[z].Tipus = darab[3];
                    eredmeny[z].Nyeremeny = int.Parse(darab[4]);
                    z++;
                }
                poker_csv.Close();
                Console.WriteLine("0.Feladat\nA fájlbeolvasás megtörtént!");
                return true;
            }
            catch (Exception hiba)
            { Console.WriteLine("0.Feladat\nHiba történt a fájlkiírás közben! "+hiba.Message);
                return false;
            }
        }

        static bool Kiiras()
        {
            int t;
            int u = 0;
            bool jo;

            for (int i = 0; i < z; i++)
            {
                jo = false;
                for (t = 0; t < u; t++)
                {
                    if (eredmeny[i].Nev == ossz[t].Nev)
                    {
                        jo = true; ossz[t].Nyeremeny += eredmeny[i].Nyeremeny; break;
                    }
                }
                if (!jo)
                {
                    ossz[u].Nev = eredmeny[i].Nev;
                    ossz[u].Nyeremeny = eredmeny[i].Nyeremeny;
                    u++;
                }
            }

            try
            {
                StreamWriter jatekos_txt = new StreamWriter("jatekos.txt", false, Encoding.Default);
                for (t = 0; t < u; t++)
                {
                    jatekos_txt.WriteLine(ossz[t].Nev +" " + ossz[t].Nyeremeny+" "+"FT.");
                }
                jatekos_txt.Close();
                return true;
            }
            catch (Exception hiba)
            { Console.WriteLine("4.Feladat\nA fájlkiírás közben hiba történt! "+hiba.Message );
                return false;
            }
        }

        static void Main(string[] args)
        {
            if (Beolvas())
            {
                int legnagyobb = int.MinValue;
                Eredmenyek legtobb = new Eredmenyek();
                for(int i=0;i<z;i++)
                {
                    if (eredmeny[i].Nyeremeny > legnagyobb)
                    {
                        legnagyobb = eredmeny[i].Nyeremeny;
                        legtobb = eredmeny[i];
                    }
                }
                Console.WriteLine($"1.Feladat\nA legnagyobb nyereménye {legtobb.Nev} vol a {legtobb.Forduloszam}. fordulóban {legtobb.Nyeremeny} FT.");

                Console.WriteLine("Írja be egy játékos nevét: ");
                string beNev = Console.ReadLine().Trim();
                int db = 0;
                for (int i = 0; i < z; i++)
                {
                    if (eredmeny[i].Nev == beNev)
                    {
                        db++;
                    }
                }
                if (db > 0)
                {
                    Console.WriteLine($"2.feladat\n{beNev} nevű játékos összesen {db} fordulóban játszott");
                }
                else
                {
                    Console.WriteLine("Ilyen nevű játékos nem volt a versenyen!");
                }

                int tDB = 0, tO = 0;
                int oDB = 0, oO = 0;
                for (int i = 0; i < z; i++)
                {
                    if (eredmeny[i].Tipus == "Texas Hold'Em")
                    { tDB++; tO += eredmeny[i].Nyeremeny; }
                    if (eredmeny[i].Tipus == "Ötlapos póker")
                    { oDB++; oO += eredmeny[i].Nyeremeny; }
                }
                Console.WriteLine($"3.Feladat\nTexas Hold’Em esetén a nyeremény átlagosan: {Math.Round((double)tO/tDB),0} FT.\n" +
                    $"Ötlapos póker esetén a nyeremény átlagosan: {Math.Round((double)oO/oDB,0)} Ft.");

            }
            if (Kiiras())
            {
                Console.WriteLine("4.Feladat\nA fájlkiírás megtörtént!");
            }
            else
            { Console.WriteLine("Viszlát!"); }

            Console.ReadKey();

        }
    }
}
