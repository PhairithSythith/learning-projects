﻿//5-40 veletlen szam <- ellátmányok 1 nap +tomb hossza
Random rnd = new Random();
int ellatmany = rnd.Next(5,41);
int[] tomb = new int[ellatmany];

//kérjük be hány ember él ha <1 akkor 1-51 között új szám
int emberek = 0;
Console.WriteLine("Hányan élnek a bolygón? ");
emberek = Convert.ToInt32(Console.ReadLine());
if (emberek < 1)
{ emberek = rnd.Next(1,51); }

//tömb feltöltése ha emberek páros 51-100, ha páratlan 1-50
for (int i=0;tomb.Length;)
{ }