﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace proggyak1026
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //1,véletlen szám 5-40->tömb hossza is ez
            //2, kérd be az emberek sámát, ha kisebb mint 1 aakor új véletlen szám 1-50 között
            //3, töltsd fel a tömböt véletlen számokkal, ha páros a bekért szám akkor 51-100 között, ha páratlan akkor 1-50 között
            //
            // 1-2-3-4-5
            //3-8-12-20-7
            // emberek= 6
            //a, összállomány átlaga (3+8+12+20+7)/5 kerekítve!!
            //b, hány napra elég a készlet a kolóniának (2x fogyaszt 1 ember) (3+8+12+20+7)/(2*emberek száma)
            //c, hány nap van amikor nem jut mindenkinek ellátmány (12 > napi ellámány vagyis [i]) 
            //d, átlagosan elegendő e mindenkinek az ellátmány (átlag/emberek*2)
            //e, a legtöbb ellátmánnyal rendelkező napon 1 embernek meddig lenne elég (max/2)

            Random rnd = new Random();
            int ellatmany = rnd.Next(5,41);
            int[] kaja = new int[ellatmany];
            int emberek = 0;
            

            Console.WriteLine("Hányan élnk a bolygón? ");
            emberek = Convert.ToInt32(Console.ReadLine());
            if (emberek < 1)
            { emberek = rnd.Next(1,51); }
            Console.WriteLine($"Ennyi ember él a bolygón: {emberek}");

            for (int i = 0; i < kaja.Length; i++)
            { if (emberek % 2 == 0)
                { kaja[i] = rnd.Next(51, 101); }
                else { kaja[i] = rnd.Next(1,51); }
            }
            Console.WriteLine($"A tömb elemei: {string.Join(",", kaja)}");

            int osszesel = kaja.Sum();
            Console.WriteLine($"Az összellátmány: {osszesel}");
            int atlag = (int)Math.Round((double) osszesel / kaja.Length);
            Console.WriteLine($"Az összellátmány átlaga: {atlag}");

            int fogyasztas = 2 * emberek;
            int eleg = osszesel / fogyasztas;
            Console.WriteLine($"Ennyi napra elég a készlet a teljes kolóniának: {eleg}");

            int nemeleg = 0;
            foreach (int no in kaja)
            { if (no < fogyasztas)
                    nemeleg++;
                }
            Console.WriteLine($"Ennyi nap nem jut mindenkinek ellátmány: {nemeleg}");


            int elegendo = atlag / fogyasztas;
                if (elegendo>=fogyasztas)
                 Console.WriteLine("Átlagosan elegendő az ellátmány");
                else  Console.WriteLine("Átlagosan nem elegendő az ellátmány"); 

                int legtobb = 0;
            for (int i = 0; i < kaja.Length; i++)
            {
                if (kaja[i] > legtobb)
                { legtobb = kaja[i]; }
            }
                Console.WriteLine($"Ennyi napig lenne neki elég: {legtobb/2}");

                
            
        }
    }
}