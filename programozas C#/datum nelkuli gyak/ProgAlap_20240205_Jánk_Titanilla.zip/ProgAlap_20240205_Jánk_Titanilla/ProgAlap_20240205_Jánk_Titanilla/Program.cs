﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProgAlap_20240205_Jánk_Titanilla
{
           public struct Auto
        {
            public string Tipus, Szin;
            public int GyartasiEv, Ar, FutottKm;
        }


        internal class Program
        {
            static Auto[] kocsik = new Auto[30];
            static int z = 0;
            static double sz90, sz20, sz21;

        static bool Beolvas()
            {
                try
                {
                    StreamReader autok_csv = new StreamReader("autok.csv", Encoding.Default);
                    while (!autok_csv.EndOfStream)
                    {
                        string[] sor = autok_csv.ReadLine().Split(';');
                        kocsik[z].Tipus = sor[0];
                        kocsik[z].Szin = sor[1];
                        kocsik[z].GyartasiEv = int.Parse(sor[2]);
                        kocsik[z].Ar = int.Parse(sor[3]);
                        kocsik[z].FutottKm = int.Parse(sor[4]);
                        z++;
                    }
                     autok_csv.Close();
                    Console.WriteLine("0.Feladat\nA fájlbeolvasás sikeres!");
                    return true;
                }
                catch (Exception hiba)
                {
                    Console.WriteLine("0.Feladat\nHiba történt: " + hiba.Message);
                    return false;
                }
            }

        static bool Kiir()
        {
            try
            {
                StreamWriter statisztika_txt = new StreamWriter("statisztika.txt", false, Encoding.Default);

                statisztika_txt.WriteLine($"1990–2000 között gyártott autók: {sz90} %");
                statisztika_txt.WriteLine($"2001–2010 között gyártott autók: {sz20} %");
                statisztika_txt.WriteLine($"2011–2023 között gyártott autók: {sz21} %");

                statisztika_txt.Close();
                return true;
            }
            catch (Exception hiba)
            {
                Console.WriteLine("4.Feladat\nFájlírás közben hiba történt! " + hiba.Message);
                return false;
            }
        }


        static void Main(string[] args)
            {

            if (Beolvas())
            {
                int maxAr = int.MinValue;
                Auto legdragabb = new Auto();

                for (int i = 0; i < z; i++)
                {
                    if (kocsik[i].Ar > maxAr)
                    {
                        maxAr = kocsik[i].Ar;
                        legdragabb = kocsik[i];
                    }
                }

                Console.WriteLine($"1.Feladat\nA legdrágább autó: {legdragabb.Tipus}, {legdragabb.Ar} Ft, {legdragabb.FutottKm} km.");

                Console.Write("\nÍrja be egy autó típusát: ");
                string beTipus = Console.ReadLine();
                int db = 0;

                for (int i = 0; i < z; i++)
                {
                    if (kocsik[i].Tipus == beTipus)
                        db++;
                }

                if (db > 0)
                    Console.WriteLine($"2.Feladat\nA {beTipus} típusú autókból {db} darab van.");
                else
                    Console.WriteLine("2.Feladat\nlyen típusú autó nincs a kereskedésben!");

                int db90 = 0, db20 = 0, db21 = 0;

                for (int i = 0; i < z; i++)
                {
                    if (kocsik[i].GyartasiEv >= 1990 && kocsik[i].GyartasiEv <= 2000)
                        db90++;
                    else if (kocsik[i].GyartasiEv >= 2001 && kocsik[i].GyartasiEv <= 2010)
                        db20++;
                    else if (kocsik[i].GyartasiEv >= 2011 && kocsik[i].GyartasiEv <= 2023)
                        db21++;
                }

                double sz90 = Math.Round(db90 * 100.0 / z, 2);
                double sz20 = Math.Round(db20 * 100.0 / z, 2);
                double sz21 = Math.Round(db21 * 100.0 / z, 2);

                Console.WriteLine("\n3.Feladat");
                Console.WriteLine($"1990–2000 között gyártott autók: {sz90} %");
                Console.WriteLine($"2001–2010 között gyártott autók: {sz20} %");
                Console.WriteLine($"2011–2023 között gyártott autók: {sz21} %");

            }
            if (Kiir())
            {
                Console.WriteLine("4.Feladat\nA fájlba írás sikeres!");
            }
            else
            { Console.WriteLine("Viszlát!"); }

                Console.ReadKey();
            }
        }
    }
