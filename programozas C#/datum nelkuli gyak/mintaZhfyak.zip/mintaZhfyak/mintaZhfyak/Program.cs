﻿//kérj be 25-40 között számot
int szam;
do
{
    Console.WriteLine("Írjon be egy számot 25 és 40 között: ");
    szam = Convert.ToInt32(Console.ReadLine());
} while (szam<=25 || szam>=40);
//szorozzuk meg 2-5 közötti random számmal
Random rnd = new Random();
szam = szam * rnd.Next(2,6);
//kell egy tömb ami a kapott szám harmada
int harmad = (int)Math.Round((double) szam/3 );
int[] szamok = new int[harmad];
//töltsük fel a tömböt -100-100 közötti számokkal
for (int i = 0; i < szamok.Length; i++)
{
    szamok[i] = rnd.Next(-100,100);
}
//írja ki az elemek átlagát
Console.WriteLine($"Az elemek átlaga: {szamok.Average():F2}");
//válasszon ki véletlenszerűen egy elemet index alapján
int veletlen = rnd.Next(0,szamok.Length);
int relem = szamok[veletlen];
Console.WriteLine($"A random index alapján kiválasztott elem: {relem}");

//Minden számhoz adja hozzá a tömbindexének a 2x

int osszeg = 0;
for (int i = 0; i < szamok.Length; i++)
{
    osszeg = osszeg + szamok[i] + i * 2;
}
Console.WriteLine($"Az elemek a hozzájuk adott indexükkel: {osszeg}");
// mennyit kell hozzáaadni az elemek osszegehez hogy ne legyen negativ
int negativ = 0;
foreach (int sz in szamok)
{
    if (sz < 0)
    { negativ += Math.Abs(sz); }
}
Console.WriteLine($"Ennyit kell hozzáadni az elemekhez hogy ne legyen negatív: {negativ}");