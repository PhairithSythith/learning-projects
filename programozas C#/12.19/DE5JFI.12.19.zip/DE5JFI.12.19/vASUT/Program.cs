﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace vASUT
{
    internal class Program
    {
        static void Main(string[] args)
        {
           Kiir(Osszeg(General()));
        }
        static int[] General()
        { Random rnd = new Random();
            int[] ulohelyek = new int[80];
            for (int i = 0; i < ulohelyek.Length; i++)
            { ulohelyek[i] = rnd.Next(100,501);
                if (ulohelyek[i] == ulohelyek[i])
                    ulohelyek[i] = rnd.Next(100,501);
            }
            return ulohelyek;
        }

        static int Osszeg(int[] ulohelyek)
        {
            int paratlan = 0;
            int ar = 560;
            int fizet = 0;
            for (int i = 0; i < ulohelyek.Length; i++)
            { if (ulohelyek[i] % 2 == 1)
                 paratlan++;
                fizet = paratlan * ar;
                    
            }
            return fizet;
            
        }

        static void Kiir(int var)
        { Console.WriteLine($"A páratlan helyekért fizetendő végösszeg: {var} "); }

    }
}
