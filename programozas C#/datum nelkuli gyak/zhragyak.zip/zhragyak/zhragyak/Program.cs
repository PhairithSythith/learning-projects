﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zhragyak
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // 10 véletlen szám generálása 1 és 100 között
            // majd a számok kiírás, összegzés és átlagolás
            // végén a legnagyobb és legkisebb szám kiírása
            // kiíratás növekvő és csökkenő sorrendben is

            Random rnd = new Random();
            int[] tomb = new int[10];
            for (int i = 0; i < tomb.Length; i++)
            { tomb[i] = rnd.Next(1, 101); }
            Console.WriteLine($"A tömb elemei: {string.Join(",", tomb)}");

            int osszeg = tomb.Sum();
            Console.WriteLine($"A tömb elemeinek az összege: {osszeg}");

            int atlag = (int)Math.Round((double)osszeg / tomb.Length);
            Console.WriteLine($"A tömb elemeinek az átlaga: {atlag}");

            int legkisebb = 0;
            int legnagyobb = 0;
            for (int i = 0; i < tomb.Length; i++)
            {
                legkisebb = tomb.Min();
                legnagyobb = tomb.Max();
            }
            /*for (int i = 0; i < tomb.Length; i++)
            { if (tomb[i] > legnagyobb)
                    legnagyobb = tomb[i];
                if (tomb[i] < legkisebb)
                    legkisebb = tomb[i];  //legkisebb nem jó értéket ír ki (0 mindig)
            }*/
            /*
            foreach (int leg in tomb)
            { if (leg < legkisebb)
                    legkisebb = leg;}*/ //legkisebb ugyanúgy van itt is, miindig 0-át ír
            Console.WriteLine($"A tömb legkiseebb eleme: {legkisebb}");
            Console.WriteLine($"A tömb legnagyobb eleme: {legnagyobb}");

            for (int i = 0; i < tomb.Length - 1; i++)
            {
                for (int j = i + 1; j < tomb.Length; j++)
                {
                    if (tomb[i] > tomb[j])
                    {
                        int csere = tomb[i];
                        tomb[i] = tomb[j];
                        tomb[j] = csere;
                    }
                }
            }
            Console.WriteLine($"Az elemek növekvő sorrendben: {string.Join(",", tomb)}");

            for (int i = 0; i < tomb.Length - 1; i++)
            {
                for (int j = i + 1; j < tomb.Length; j++)
                {
                    if (tomb[i] < tomb[j])
                    {
                        int csere = tomb[i];
                        tomb[i] = tomb[j];
                        tomb[j] = csere;
                    }
                }
            }
            Console.WriteLine($"Az elemek csökenő sorrendben: {string.Join(",", tomb)}");

            /*Írj egy programot hogy: Van Zoli, zoli egy nap vagy nem dolgozik vagy max 12 őrát dolgozhat
             * Zoli egy hónapban min 10 max 22 napot dolgozhat
             * Zoli órabére 2985/FT 
             * Mennyit keres Zoli 1 hónap alatt és mennyit keres 1 év alatt?
             * Mennyit dolgozik Zoli egy hónap alatt?
             * Mennyit dolgozik Zoli egy év alatt?
             * Mennyit keres Zoli egy nap alatt?
             * Ha Zoli minden hónapban és minden nap más mennyiséget dolgozik akkor mennyi a havi és éves bére?
             * 
            */

            Console.WriteLine();
            Console.WriteLine("Zoli munkájának és bérének a kalkulációja:");
            Random rnd2 = new Random();
            int oraBer = 2985;
            int honapNapjai = rnd2.Next(10, 23); //10 és 22 nap között
            int honapOrai = 0;
            for (int i = 0; i < honapNapjai; i++)
            {
                int napiOra = rnd2.Next(0, 13); //0 és 12 óra között
                honapOrai += napiOra;
            }
            int honapBere = honapOrai * oraBer;
            int evBere = honapBere * 12;
            int evOrai = honapOrai * 12;
            Console.WriteLine($"Zoli egy hónap alatt {honapOrai} órát dolgozik.");
            Console.WriteLine($"Zoli egy hónap alatt {honapBere} Ft-ot keres.");
            Console.WriteLine($"Zoli egy év alatt {evOrai} órát dolgozik.");
            Console.WriteLine($"Zoli egy év alatt {evBere} Ft-ot keres.");
            Console.WriteLine($"Zoli egy nap alatt átlagosan {(double)honapOrai / honapNapjai:0.00} órát dolgozik.");
            Console.WriteLine($"Zoli egy nap alatt átlagosan {(double)honapBere / honapNapjai:0.00} Ft-ot keres.");
            Console.WriteLine($"Zoli egy év alatt átlagosan {(double)evOrai / (honapNapjai * 12):0.00} órát dolgozik.");
            Console.WriteLine($"Zoli egy év alatt átlagosan {(double)evBere / (honapNapjai * 12):0.00} Ft-ot keres.");
            Console.WriteLine($"Zoli egy hónapban {honapNapjai} napot dolgozik.");
            Console.WriteLine($"Zoli egy évben {honapNapjai * 12} napot dolgozik.");
            Console.WriteLine($"Zoli egy nap alatt {oraBer} Ft-ot keres óránként.");
            Console.WriteLine();
            for (int i = 0; i < honapNapjai; i++)
            {
                int napiOra = rnd2.Next(0, 13);
                int napiBer = napiOra * oraBer;
                Console.WriteLine($"Zoli a(z) {i + 1}. napon {napiOra} órát dolgozik és {napiBer} Ft-ot keres.");
            }
            Console.WriteLine();
            Console.WriteLine($"Zoli egy évben a következőképpen dolgozik és keres:");
            for (int i = 0; i < 12; i++)
            {
                int honapNapjai2 = rnd2.Next(10, 23);
                int honapOrai2 = 0;
                for (int j = 0; j < honapNapjai2; j++)
                {
                    int napiOra2 = rnd2.Next(0, 13);
                    honapOrai2 += napiOra2;
                }
                int honapBere2 = honapOrai2 * oraBer;
                Console.WriteLine($"Zoli a(z) {i + 1}. hónapban {honapOrai2} órát dolgozik és {honapBere2} Ft-ot keres.");
              



                Console.ReadKey();
            }
        }
    }
}
