﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;

namespace Fajlok
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("A leghosszabb fájlnév: " + Leghosszabb());

            Console.ReadKey();
        }

        static string[] Beker()
        {
            string beolvasando;
            string fajlnev;
            string[] fajltomb;
            Console.WriteLine("Menniy fájlt szeretne beolvasni: ");
            beolvasando = Console.ReadLine();
            fajltomb = new string[Convert.ToInt32(beolvasando)];
            for (int v = 0; v < fajltomb.Length; v++)
            {
                Console.WriteLine("Adja meg a fájlnevet: ");
                fajlnev = Console.ReadLine().ToLower();
                
                for (int i = 0; i < fajltomb.Length; i++)
                {
                    fajltomb[i] = fajlnev;
                }
            }
          
            return fajltomb;
        }

        static string Leghosszabb()
        { string[] fajltomb = Beker();
            string leghosszabb = fajltomb.Max();
            return leghosszabb;
        }

    }
}
