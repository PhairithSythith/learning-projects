﻿//1. generál 1-100 között számokat, tedd tömbbe, írd ki az összegüket és az átlagukat, a párosokból csinálj páratlant
int[] szamok = new int[10];
Random rnd = new Random();
int osszeg=0;
    for (int i = 0; i < szamok.Length; i++)
    {
        szamok[i] = rnd.Next(1, 101);
        osszeg += szamok[i];
    }
    double atlag = (double)osszeg /szamok.Length;

int pozitiv = 0;
if (pozitiv / 2 == 0)
{
    pozitiv++;
}
else ;
    Console.WriteLine($"A generált számok: {string.Join(",", szamok)}");
Console.WriteLine($"A számok összege: {osszeg}");
Console.WriteLine($"A számok átlaga: {atlag:F2}" );