﻿Console.WriteLine("Üdvözlöm! Hogy híják? ");
string nev = Console.ReadLine();
int a,b = 0;
    Console.WriteLine($"{nev} válasszon egy számot amit össze akar adni: ");
    a = Convert.ToInt32(Console.ReadLine());
    Console.WriteLine($"{nev} válasszon egy másik számot amit össze akar adni az előzővel: ");
    b = Convert.ToInt32(Console.ReadLine());
    Console.WriteLine($"{nev} a számok összege: {a+b}");
Console.WriteLine();
    Console.WriteLine($"{nev} most válasszon egy TÖRT (pl 1,2) számot aminek\n szeretné tudni a négyzetét: ");
    double c = Convert.ToDouble(Console.ReadLine());
    Console.WriteLine($"{nev} most válasszon másik TÖRT (pl 1,2) számot aminek\n szeretné tudni a négyzetét: ");
    double d = Convert.ToDouble(Console.ReadLine());
    Console.WriteLine($"A számok négyzetei: {c*2} és {d*2}");





/* Árgilán tanárúr online óra 2025.10.09 (félbehagyva hálózati problémák miatt)
using System.ComponentModel.Design;
using System.Xml;

Console.WriteLine("A program a Prt bizonyos tételeit mutatja be.\n" +
    "Szükségünk  lesz néhány adatra. kérem adja meg az adatokat számomra");
byte n;
do
{
    Console.Write("Kérem adja mef a csoport létszámát! 1<=n <=20 n=0");
    try
    {
        n = byte.Parse(Console.ReadLine());
        if (1 <= n && n <= 20) break;
        else Console.WriteLine("A megadott érték nem felel meg a feltételeknek");
    }
    catch
    {
        Console.WriteLine("Sajnos a megadott adat hibás!....");
    }
} while (true);

//létrehozom a tömböt
double[] magas = new double [n];
Console.WriteLine("Kérem adja meg a csoporttagok magasságát!");
for (int i = 0; i < magas.Length; i++)
{
    Console.Write($"{i + 1}. tag magassága");
    magas[i] = double.Parse(Console.ReadLine());
    do
    {
        try
        {
            magas[i] = double.Parse(Console.ReadLine());
            if (1.5 <= magas[i] && magas[i] <= 1.95) break;
            else Console.WriteLine("A megadott magasság nem felel meg");

        }
        catch
        {
            Console.WriteLine("A megadott magasság nem alakítható át");
        }
    } while (true);
}
double max = double.MinValue;
for (int i = 0; i < n; i++)
{
    if (max < magas[i]) ;
    { max = magas[i]; }
}
Console.WriteLine($"A legmagasabb csoporttag magassága");*/
    Console.ReadKey();