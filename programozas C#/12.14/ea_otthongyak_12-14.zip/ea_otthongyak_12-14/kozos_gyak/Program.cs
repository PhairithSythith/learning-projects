﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace kozos_gyak
{ 
    public struct Eredmeny
    {
        public string KeresztNev, Tipus;
        public int FSorSzam, AsztalSzam, Nyeremeny;
    }

    public struct Ossz
    {
        public string KeresztNev;
        public int Nyeremeny;
    }

    internal class Program
    {
        static int z = 0;
        static Eredmeny[] eredmenyek = new Eredmeny[40];
        static Ossz[] osszes = new Ossz[40];

        static bool Beollvas()
        {
            try
            {
                StreamReader poker_csv = new StreamReader(@"C:\Users\ritzo\source\repos\ea_otthongyak_12-14\kozos_gyak\bin\poker.csv", Encoding.Default);
                while (!poker_csv.EndOfStream)
                {
                    string[] darabok = poker_csv.ReadLine().Split(';');
                    eredmenyek[z].KeresztNev = darabok[0].Trim();
                    eredmenyek[z].FSorSzam = int.Parse( darabok[1].Trim());
                    eredmenyek[z].AsztalSzam = int.Parse(darabok[2].Trim());
                    eredmenyek[z].Tipus = darabok[3].Trim();
                    eredmenyek[z].Nyeremeny = int.Parse(darabok[4].Trim());
                    z++;
                }
                poker_csv.Close();
                Console.WriteLine("0.Feladat\nA fájlbeolvasás megtörtént!");
                return true;

            } catch (Exception hiba)
            { Console.WriteLine("0.Feladat\nA fájlbeolvasás közben hiba történt! "+hiba.Message);
                return false;
            }
        }

        static bool Kiir()
        {
            int t;
            int u = 0;
            bool Jo;

            for (int i = 0; i < z; i++)
            {
                Jo = false;
                for (t = 0; t < u; t++)
                {
                    if (osszes[t].KeresztNev == eredmenyek[i].KeresztNev)
                    {
                        osszes[t].Nyeremeny += eredmenyek[i].Nyeremeny;
                        Jo = true;
                        break;
                    }
                }

                if (!Jo)
                {
                    osszes[u].KeresztNev = eredmenyek[i].KeresztNev;
                    osszes[u].Nyeremeny = eredmenyek[i].Nyeremeny;
                    u++;
                }
            }

            try
            {
                StreamWriter jatekos_txt = new StreamWriter(@"C:\Users\ritzo\source\repos\ea_otthongyak_12-14\kozos_gyak\bin\jatekos.txt", false, Encoding.Default);
                for (t = 0; t < u; t++)
                {
                    jatekos_txt.WriteLine(osszes[t].KeresztNev+ " " + osszes[t].Nyeremeny + " " + "FT.");
                }
                jatekos_txt.Close();
                return true;

            } catch (Exception hiba)
            { Console.WriteLine("4.Feladat\nHiba történt a fájlkiírás közben! "+ hiba.Message);
                return false;
            }
        }

        static void Main(string[] args)
        {
            Console.OutputEncoding = Encoding.Default;
            Console.InputEncoding = Encoding.Default;

            if (Beollvas())
            {
                int legnagyobb = int.MinValue;
                Eredmeny legtobb = new Eredmeny();
                for (int i = 0; i < z; i++)
                {
                    if (eredmenyek[i].Nyeremeny > legnagyobb)
                    {
                        legnagyobb = eredmenyek[i].Nyeremeny;
                        legtobb = eredmenyek[i];
                    }
                }
                Console.WriteLine($"1.Feladat\nA legnagyobb nyereménye {legtobb.KeresztNev} volt a {legtobb.FSorSzam}. fordulóban");

                Console.WriteLine("Írja be egy játékos nevét: ");
                string BeNev = Console.ReadLine().Trim();
                int db = 0;
                for(int i=0;i<z;i++)
                {
                    if (eredmenyek[i].KeresztNev == BeNev)
                    {
                        db++;   
                    }
                }
                if (db != 0)
                {
                    Console.WriteLine($"2.Feladat\n{BeNev} játékos {db}. fordulóban játszott összesen!");
                }
                else
                {
                    Console.WriteLine("2.felladat\nIlyen nevű játékos nem volt a versenyen!");
                }

                int texDB = 0, texOssz = 0;
                int otDB = 0, otOsz = 0;
                for (int i = 0; i < z; i++)
                {
                    if (eredmenyek[i].Tipus == "Texas Hold'Em")
                    {
                        texDB++; texOssz += eredmenyek[i].Nyeremeny;
                    }
                    if (eredmenyek[i].Tipus == "Ötlapos póker")
                    {
                        otDB++; otOsz += eredmenyek[i].Nyeremeny;
                    }
                }
                Console.WriteLine($"3.Feladat\nTexas Hold’Em esetén a nyeremény átlagosan: {Math.Round((double)texOssz/texDB)} FT.\n" +
                    $"Ötlapos póker esetén a nyeremény átlagosan: {Math.Round((double)otOsz/otDB)} FT.");

            }
            if (Kiir())
            {
                Console.WriteLine("4.Feladat\nA fájlkiírás sikeres volt!");
            }
            else
            { Console.WriteLine("Viszlát!"); }
            Console.ReadKey();
        }
    }
}
