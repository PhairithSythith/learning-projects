﻿using System.ComponentModel.Design;
using System.Threading.Channels;

string nev = " ";
bool helyesNev = false;
while (!helyesNev)
{
    Console.WriteLine("Kérem adja meg a nevét: ");
    nev = Console.ReadLine();
    if (nev.Any(char.IsDigit) || (string.IsNullOrWhiteSpace(nev))) 
    { Console.WriteLine("Nem adott meg nevet vagy a név számot tartalmaz, próbálja újra!"); }
    else { helyesNev = true; }
}
Console.WriteLine($"Üdvözlöm {nev}!");

Console.WriteLine($"Kedves {nev}, mennyi almát szeretne vásárolni, ha 1kg/ 400 FT az alma ára? ");
int almaMennyiség = int.Parse(Console.ReadLine());
int almaÁra = 400;
if (almaMennyiség<0)
{ Console.WriteLine("Az alma mennyisége nem lehet negatív!");  }
else if (almaMennyiség ==0)
{ Console.WriteLine("Nem vásárolt almát!");  }
else if (almaMennyiség>0)
{ Console.WriteLine($"{nev} a megvásárolni kívánt {almaMennyiség} kg alma {almaMennyiség*almaÁra} Ft");}
else
{ Console.WriteLine("Nem számot adott meg!");  }

    Console.WriteLine($"{nev} adja meg, hogy a kókusz hány grammos legyen,\nés a rendszer kiszámolja önnek, hogy hány fecske tudná elcipelni: ");
int kókuszSúly = int.Parse(Console.ReadLine());
int fecskesúlya = 60;
int cipel = fecskesúlya / 3;
int fecskeSzám = kókuszSúly / cipel;
switch 
    (fecskeSzám)
{ case < 0: Console.WriteLine("Nem lehet negatív a kóksu súlya!"); break;
    case 0: Console.WriteLine("A kókusz súlya nem lehet 0!"); break;
    case > 0: Console.WriteLine($"A kókusz súlya {kókuszSúly} gramm, így {fecskeSzám} fecske tudja elcipelni!"); break;
    default: { Console.WriteLine("Nem számot adott meg!"); break; }}

Console.WriteLine($"{nev} most adja meg a fecskék számát és a rendszer\nkiszámolja önnek, hogy hány 8 grammos cseresznyét tudnak elcipelni: ");
int fecskeDarab = int.Parse(Console.ReadLine());
int cseresznyeSúlya = 8;
int cseresznyeCipel = cipel / cseresznyeSúlya;
int cseresznyeDarab = fecskeDarab * cseresznyeCipel;
switch
    (cseresznyeDarab)
{ case < 0: Console.WriteLine("Nem lehet negatív a fecskék száma!"); break;
    case 0: Console.WriteLine("A fecskék száma nem lehet 0!"); break;
    case > 0: Console.WriteLine($"{fecskeDarab} fecske {cseresznyeDarab} darab cseresznyét tud elcipelni");break;
    default: { Console.WriteLine("Nem számot adott meg!"); break; }}

Console.WriteLine($"{nev} most adjon meg egy számot és megmondom, hogy páros vagy páratlan-e: ");
int szám = int.Parse(Console.ReadLine());
if (szám % 2 == 0)
{Console.WriteLine("A szám páros!");}
else if (szám%2 !=0)
{Console.WriteLine("A szám páratlan!");}
else
{ Console.WriteLine("Nem számot adott meg!");}
Console.WriteLine($"{nev} most válasszon egy számot és a rendszer megmondja, hogy pozitív, negatív vagy 0: ");
int szám2 = int.Parse(Console.ReadLine());
if (szám2 > 0)
{ Console.WriteLine("A szám pozitív"); }
else if (szám2 < 0)
{ Console.WriteLine("A szám negatív!"); }
else if (szám2 == 0)
{ Console.WriteLine("A szám 0!"); }
else
{ Console.WriteLine("Nem számot adott meg!"); }

Console.WriteLine($"{nev} most válasszon kettő számot és a rendszer kiszámolja önnek\nhogy melyik a nagyobb és mennyivel: ");
string szám3 =Console.ReadLine ();
string[] elválasztó = szám3.Split (' ', ',', ';', '-');
int szám4 = int.Parse(elválasztó[0]);
int szám5 = int.Parse(elválasztó[1]);
if (szám4 > szám5)
{ int kulonbseg = szám4 - szám5; Console.WriteLine($" A {szám4} a nagyobb szám és {kulonbseg} több mint {szám}"); }
else if(szám5> szám4)
{ int kulonbseg2 = szám5 - szám4; Console.WriteLine($"{szám5} a nagyobb szám és {kulonbseg2} több mint {szám4}"); }
else if (szám4==szám5)
{Console.WriteLine($"A két szám egyforma!");}
else
{ Console.WriteLine("Nem számot adott meg!"); }

Console.WriteLine($"{nev} most válasszon egy számot, és a rendszer megmondja,hogy\nosztható-e 2-vel,3-al és 5-tel: ");
int szam = int.Parse(Console.ReadLine());
switch
    (szam)
{ case < 0: Console.WriteLine("Nem lehet negatív szám!"); break;
    case 0: Console.WriteLine("0-val minden szám osztható!"); break;
    case > 0 when (szam % 2 == 0 && szam % 3 == 0 && szam % 5 == 0): Console.WriteLine("A szám oszthetó 2-vel, 3-al és 5-tel!"); break;
    case > 0 when (szam % 2 == 0 && szam % 3 == 0): Console.WriteLine("A szám osztható 2-vel és 3-al!"); break;
    case > 0 when (szam % 2 == 0 && szam % 5 == 0): Console.WriteLine("A szám osztható 2-vel és 5-tel!"); break;
    case > 0 when (szam % 3 == 0 && szam % 5 == 0): Console.WriteLine("A szám osztható 3-al és 5-tel!"); break;
    case > 0 when (szam % 2 == 0): Console.WriteLine("A szám osztható 2-vel!"); break;
    case > 0 when (szam % 3 == 0): Console.WriteLine("A szám osztható 3-al!"); break;
    case > 0 when (szam % 5 == 0): Console.WriteLine("A szám osztható 5-tel!"); break;
    case > 0: Console.WriteLine("A szám nem osztható 2-vel, 3-al vagy 5-tel!"); break; }