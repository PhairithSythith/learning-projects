﻿//kérjünk be 25-40 között számot

int szam2 ;
do
{
    Console.WriteLine("Írjon be 25-40 közötti számot: ");
    szam2 = Convert.ToInt32(Console.ReadLine());
} while (szam2 <= 25 || szam2 >= 40);

// szorozzuk meg a bekért számot 2-5 közötti random számmal
Random rnd = new Random();
szam2 = szam2*rnd.Next(2,6);

//Legyen tömb ami a kapott szám harmada legyen 
int harmad = (int)Math.Round((double)szam2/3);
int[] tomb = new int[harmad];

//töltsük fel -100-100 közötti számokkal
// írja ki a tomb elemeinek átlagát
for (int i = 0; i < tomb.Length; i++)
{
    tomb[i] = rnd.Next(-100, 101);
}
Console.WriteLine($"A tömb elemei:{string.Join(",", tomb)}");
Console.WriteLine($"A tömb elemeinek átlaga: {tomb.Average():F2}");
//válasszon ki egy random elemet index alapján

 int veletlen = rnd.Next(0,tomb.Length);
int elem = tomb[veletlen];
Console.WriteLine($"Véletlenszerűen kiválasztott elem: {elem}");


//minden számhoz adjuk hozzá az indexének a 2x

for (int i = 0; i < tomb.Length; i++)
{
    tomb[i] = tomb[i] + i * 2;
    
}
Console.WriteLine($"Az elemek a hozzáadott és megszorzott indexxel: {string.Join(",", tomb)}");

//mennyit kell hozzáadni az összeghez hogy ne legyen benne negatív

int negativ = 0;
foreach (int t in tomb)
{ 
    if (t<0)
    { negativ = negativ + Math.Abs(t); }
}
Console.WriteLine($"ennyit kell hozzádni hogy ne legyen benne negatív: {negativ}");

Console.ReadKey();