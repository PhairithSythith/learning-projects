﻿using System;
using System.CodeDom;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace x1
{
    public struct Minden
    { public string nev, tipus;
        public byte azstal, fordulo;
        public int nyeremeny;
    }

    public struct Jatekos
    { public string nev;
        public int nyeremeny;
    }
    internal class Program
    {
        static int k=0;
        static Jatekos[] jatekosok = new Jatekos[40];
       static Minden[] mindenis = new Minden[40];

       
        static bool Beolvas()
        {
            try
            {
                StreamReader poker_csv = new StreamReader("poker.csv", Encoding.Default);
                while (!poker_csv.EndOfStream) {
                    string[] darab = poker_csv.ReadLine().Split(';');
                    mindenis[k].nev = darab[0];
                    mindenis[k].fordulo = byte.Parse(darab[1]);
                    mindenis[k].azstal = byte.Parse(darab[2]);
                    mindenis[k].tipus = darab[3];
                    mindenis[k].nyeremeny = int.Parse(darab[4]);
                    k++;
                }
                poker_csv.Close();
                Console.WriteLine("Az adatok beolvasása megtörtént");
                return true;
            } catch (Exception hiba)
            { Console.WriteLine("Az adatok beolvasás közben hiba történt " +hiba.Message);
                return false;
            }
            
        }

        static bool Kiir()
        {
            int z;
            int h = 0;
            bool meglett;
            for (int i = 0; i < k; i++)
            {
                meglett = false;
                for (z = 0; z < h; z++)
                {
                    if (mindenis[i].nev == jatekosok[z].nev)
                        meglett = true;
                    break;
                }
                if (meglett)
                { jatekosok[z].nyeremeny += mindenis[i].nyeremeny; }
                else
                {
                    jatekosok[h].nev += mindenis[i].nev;
                    jatekosok[h].nyeremeny += mindenis[i].nyeremeny;
                    h++;
                }
            }
            try
            {
                StreamWriter jatek_txt = new StreamWriter("jatek.txt", false, Encoding.Default);
                for (z = 0; z < h; z++)
                { jatek_txt.WriteLine($"{jatekosok[z].nev}; {jatekosok[z].nyeremeny}"); }
                jatek_txt.Close();
                return true;

            }
            catch (Exception hiba)
            {
                Console.WriteLine("Az adatok kiírása közben hiba történt " +hiba.Message);
                return false;
            }

        }

        static void Main(string[] args)
        {
            if (Beolvas())
            {
                int max = int.MinValue;
                Minden legjobb = new Minden();
                for (int i = 0; i < k; i++)
                {
                    if (mindenis[k].nyeremeny > max)
                       legjobb = mindenis[i];
                }
                Console.WriteLine($"A legnagyobb nyereménye {legjobb.nev}-nak/nek {legjobb.fordulo}. fordúlban {legjobb.nyeremeny} FT volt");

                Console.WriteLine("Írja be egy játékos  nevét: ");
                string KapottNev = Console.ReadLine().Trim();
                byte db=0 ;
                for (int i = 0; i < k; i++)
                {
                    if (mindenis[i].nev == KapottNev)
                    {
                        db++;
                    }
                }
                if (db != 0)
                    Console.WriteLine(KapottNev + " nevű játékos " + db+ " fordulóban játszott összesen");
                else
                    Console.WriteLine("Ilyen nevű játékos nem volt a versenyen!");

                int Odb = 0, OO = 0;
                int Tdb = 0, TO = 0;
                for (int i = 0; i < k; i++)
                {
                    if (mindenis[i].tipus == "Ötlapos póker")
                    { Odb++; OO += mindenis[i].nyeremeny; }
                    else { Tdb++; TO += mindenis[i].nyeremeny; }
                }
                Console.WriteLine("texas holdem átlag: " + Math.Round((double)TO / Tdb) + " FT"
                    + "\nötlapos átlag: " + Math.Round((double)OO / Odb) + " FT");

            }
            if (Kiir())
            { Console.WriteLine("Az adatok kiírása megtörtént"); }
            else { Console.WriteLine("Viszlát!"); }
            Console.ReadKey();
        }
    }
}
