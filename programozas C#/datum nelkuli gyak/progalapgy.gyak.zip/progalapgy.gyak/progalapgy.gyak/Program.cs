﻿using System.ComponentModel.Design;
using System.Globalization;
using System.Numerics;
using System.Runtime.CompilerServices;
using System.Security.Cryptography.X509Certificates;
//név bekérése
Console.WriteLine("Üdvözlöm! \nHogy hívják? ");
string nev = Console.ReadLine();

//összeadás
Console.WriteLine($"\n");

int oah, aak;
while (true)
{ 
Console.WriteLine($"Kedves  {nev}  kérem válasszon kettő tetszőleges számot, amit szeretne össze adni:  ");
string osszeadas = Console.ReadLine();
    string[] kk = osszeadas.Split(' ');
    if (kk.Length != 2)
    {
Console.WriteLine($"{nev} kettő számot kell megadnia!");
        continue;
    }
      if (int.TryParse(kk[0], out aak) &&
        int.TryParse(kk[1], out oah))
    {
        break;
    }
    else
    {
Console.WriteLine($" {nev} csak számokat adjon meg!");
    }
}
int osszeg = aak + oah;
Console.WriteLine($"{nev} a választott számok összege: {osszeg}");

//négyzet
Console.WriteLine($"\n");

float t1, t2;
while (true)
{
Console.WriteLine($" {nev} most válasszon kettő tetszőleges számot, aminek szeretné kiszámolni a négyzetét: ");
    string nygzt1 = Console.ReadLine();
    string[] negy = nygzt1.Split(' ');
    if (negy.Length != 2)
{ 
Console.WriteLine($"{nev} kettő számot kell megadnia!");
        continue;
    }
    if (float.TryParse(negy[0], out t1) &&
        float.TryParse(negy[1], out t2))
    {
        break;
    }
    else
    {
Console.WriteLine($" {nev} csak számot adjon meg!");
    }
}
        float meg = t1*t1;
        float meg2 = t2 * t2;
Console.WriteLine($"{nev} a választott számok négyzete: {meg} és {meg2}");

//tört négyzet
Console.WriteLine($"\n");

float n1, n2;
while (true)
{
Console.WriteLine($" {nev} most válasszon kettő tetszőleges TÖRT számot, aminek szeretné kiszámolni a négyzetét (pl.: 1,2): ");
    string tot1 = Console.ReadLine();
    string bevitel = tot1.Replace(',', '.');
    float.TryParse(bevitel, out n1);
    string[] tor = tot1.Split(' ');
    if (tor.Length != 2)
    {
Console.WriteLine($"{nev} kettő tört (pl.:1,2) számot kell megadnia!");
        continue;
    }
    if (float.TryParse(tor[0], out n1) &&
        float.TryParse(tor[1], out n2))
    {
        break;
    }
    else
    {
Console.WriteLine($" {nev} csak tört számot adjon meg!");
    }
}
float negyzet1 = n1 * n1;
        float negyzet2 = n2 * n2;
Console.WriteLine($"{nev} a választott számok négyzetei: {negyzet1} és {negyzet2}");

//átlag
Console.WriteLine($"\n");

float a1, a2, a3;
while (true)
{ 
Console.WriteLine($"{nev} most válasszon három tetszőleges számot, aminek szeretné kiszámolni az átlagát: ");
string atlag1 = Console.ReadLine();
string[] darabolt = atlag1.Split(' ');
if (darabolt.Length !=3)
{ 
Console.WriteLine($"{nev} 3 db számot kell megadnia!");
    continue;
}
if (float.TryParse (darabolt[0],out a1) &&
    float.TryParse(darabolt[1],out a2) &&
    float.TryParse(darabolt[2], out a3))
    {
    break;
}
else
{
Console.WriteLine($" {nev} csak számot adjon meg!");
}
}
float atlag = (a1 + a2 + a3) / 3f;
Console.WriteLine($"{nev} a választott számok átlaga: {atlag}");

//Celsius-Fahrenheit
Console.WriteLine($"\n");

Console.WriteLine($"Most {nev} írjon be egy tetszőleges C˚ amit Fahrenheitben szeretne látni: ");
string celsius = Console.ReadLine();
if (float.TryParse(celsius, out float c))
{
    float f = (c * 9 / 5) + 32;
Console.WriteLine($"{nev} a {c} C˚ az {f} F˚");
}
else
{
Console.WriteLine($" {nev} csak számot adjon meg!");
}
Console.WriteLine($"\n");

Console.WriteLine($"Most {nev} írjon be egy tetszőleges F˚ amit Celsiusban szeretne látni: ");
string fahrenheit = Console.ReadLine();
if (float.TryParse(fahrenheit, out float f2))
{
    float c2 = (f2 - 32) * 5 / 9;
Console.WriteLine($"{nev} a {f2} F˚ az {c2} C˚");
}
else
{
Console.WriteLine($" {nev} csak számot adjon meg!");
}

//idő számítás
Console.WriteLine($"\n");

float tav, seb;
while (true)
{
Console.WriteLine($" {nev} most kérem adja meg, hogy milyen messze van az úti célja (percben) és\nhogy körülbelül hány km/h-val kívánna haladni: ");
    string tavseb = Console.ReadLine();
    string[] ts = tavseb.Split(' ');
    if (ts.Length != 2)
    {
Console.WriteLine($"{nev} kettő számot kell megadnia!");
        continue;
    }
    if (float.TryParse(ts[0], out tav) &&
        float.TryParse(ts[1], out seb))
    {
        break;
    }
    else
    {
Console.WriteLine($"{nev} csak számokat adjon meg!");
    }
}
float ido = tav / seb;
Console.WriteLine($"{nev} a {seb} km/h-val a {tav} km-re lévő úticéljához \nkörülbelül    {ido}    órát kell vezetnie!");

//sebesség számítás
Console.WriteLine($"\n");

float pc, tav2;
while (true)
{
Console.WriteLine($" {nev} most adja meg hány órát szeretne vezetni (órában adja meg)\nés milyen messze van az úti célja: ");
    string prc = Console.ReadLine();
    string[] pt = prc.Split (' ');
    if (pt.Length != 2)
{ 
Console.WriteLine($" {nev} csak számot adjon meg!");
        continue;
    }
    if (float.TryParse(pt[0], out pc) &&
        float.TryParse(pt[1], out tav2))
    {
        break;
    }
    else
    {
Console.WriteLine($" {nev} csak számot adjon meg!");
    }
}
float seb2 = tav2 / pc;
Console.WriteLine($"{nev} ha {tav2} km-ert {pc} óra alatt szeretne megtenni akkor\n    {seb2}    km/h-val kell haladnia!");

//szökőév
Console.WriteLine($"\n");

int evszam;
while (true)
{
Console.WriteLine($"{nev} írjon be egy tetszőleges évet és elmondom, hogy szőkőév (volt/lesz)-e: ");
    string ev = Console.ReadLine();
    string eve = ev.Trim();
    if (int.TryParse(eve, out evszam))
    {
        break;
    }
    else
    {
Console.WriteLine($" {nev} csak számot adjon meg!");
    }
}
if ((evszam % 4 == 0 && evszam % 100 !=0) || (evszam % 400 == 0))
{
Console.WriteLine($"{nev} {evszam} szökőév (volt/lesz).");
}
else
{
Console.WriteLine($"{nev} {evszam} nem (volt/lesz) szökőév.");
}

//páros-páratlan és összesen 
Console.WriteLine($"\n");

int szm;
while (true)
{
Console.WriteLine($"{nev} válasszon egy számot és a választott számig megmondom \nhogy mennyi páros és mennyi páratlan szám van: ");
    string szam = Console.ReadLine();
    string sz = szam.Trim();
    if (int.TryParse(sz, out szm))
    {
        break;
    }
    else
    {
Console.WriteLine($"{nev} csak számot adjon meg!");
    }
}
int paros = 0;
int paratlan = 0;
for (int i = 1; i <= szm; i++)
{
    if (i % 2 == 0)
    {
        paros++;
    }
    else
    {
        paratlan++;
    }
}
Console.WriteLine($"{nev} a {szm}-ig terjedő számok között összesen {paros} db páros és {paratlan} db páratlan szám van.");

//magánhangzó-mássalhangzó
Console.WriteLine($"\n");

int maganh, masalh;
while (true)
{
Console.WriteLine($"{nev} most írjon be egy szöveget, amiből megmondom hány magánhangzó és\nmással hangzó van: ");
    string szoveg = Console.ReadLine();
    if (!string.IsNullOrWhiteSpace(szoveg))
    {
        maganh = 0;
        masalh = 0;
        foreach (char b in szoveg)
        {
            if (char.IsLetter(b))
            {
                char lowerChar = char.ToLower(b);
                if ("aáeéiíoóöőuúüű".Contains(lowerChar))
                {
                    maganh++;
                }
                else
                {
                    masalh++;
                }
            }
        }
        break;
    }
    else
    {
Console.WriteLine($" {nev} nem adott meg semmit, kérem próbálja újra!");
    }
}
Console.WriteLine($"{nev} a megadott szövegben {maganh} db magánhangzó és {masalh} db mássalhangzó van.");

//szorzó tábla
Console.WriteLine($"\n");

int szorz;
while (true)
{
Console.WriteLine($" {nev} válasszon egy tetszőleges számot aminek megmutatom\n1-10-ig a szorzótábláját: ");
    string szorzo = Console.ReadLine();
    string szor = szorzo.Trim();
    if (int.TryParse(szor, out szorz))
    {
        break;
    }
    else
    {
Console.WriteLine($" {nev} csak számot adjon meg!");
    }
}
Console.WriteLine($"\n {nev} a {szorz} szorzótáblája: ");
for (int i = 1; i <= 10; i++)
{
    int eredmeny = szorz * i;
Console.WriteLine($"{szorz} x {i} = {eredmeny}");
    }

Console.WriteLine($"\n");
//számjegyek összege
int szamjegy;
while (true)
{
    Console.WriteLine($"{nev} most válasszon egy tetszőleges számot és megmondom a számjegyek összegét: ");
    string szamjegyek = Console.ReadLine();
    string szj = szamjegyek.Trim();
    if (int.TryParse(szj, out szamjegy) && szamjegy >= 0)
    {
        break;
    }
    else
    {
        Console.WriteLine($" {nev} kérem számot adjon meg!");
    }
}
int ossz = 0;
int temp = szamjegy;
while (temp > 0)
{
    ossz += temp % 10;
    temp /= 10;
}
Console.WriteLine($"{nev} a {szamjegy} számjegyeinek összege: {ossz}");

Console.WriteLine($"\n");
//szöveg visszafelé
while (true)
{
Console.WriteLine($"{nev} most írjon be gy tetszőleges szöveget és kiírom visszafelé: ");
    string szoveg2 = Console.ReadLine();
    if (!string.IsNullOrWhiteSpace(szoveg2))
    {
        char[] chars = szoveg2.ToCharArray();
        Array.Reverse(chars);
        string visszafele = new string(chars);
Console.WriteLine($"{nev} a megadott szöveg visszafelé a következő: {visszafele}");
        break;
    }
    else
    {
Console.WriteLine($"{nev} nem adott meg semmit, próbálja újra!");
    }
}

//átváltás méter-deciméter-centiméter-milliméter
Console.WriteLine($"\n");
float meter;
while (true)
    {
    Console.WriteLine($"{nev} most adjon meg egy tetszőleges távolságot méterben és átváltom\ndeciméterre, centiméterre és milliméterre: ");
    string mer = Console.ReadLine();
    string m = mer.Trim();
    if (float.TryParse(m, out meter) && meter >= 0)
    {
        break;
    }
    else
        {
        Console.WriteLine($" {nev} csak számot adjon meg!");
        }
    }
float deci = meter * 10;
float centi = meter * 100;
float milli = meter * 1000;
Console.WriteLine($"{nev} a {meter} méter az {deci} deciméter, {centi} centiméter és {milli} milliméter.");

//faktoriális
Console.WriteLine($"\n");
int fakt;
while (true)
{
    Console.WriteLine($"{nev} most válasszon egy tetszőleges számot és kiszámolom a faktoriálisát: ");
    string faktorialis = Console.ReadLine();
    string f = faktorialis.Trim();
    if (int.TryParse(f, out fakt) && fakt >= 0)
    {
        break;
    }
    else
    {
        Console.WriteLine($" {nev} csak számot adjon meg!");
    }
}
BigInteger faktorialisEredmeny = 1;
for (int i = 1; i <= fakt; i++)
    {
    faktorialisEredmeny *= i;
}
Console.WriteLine($"{nev} a {fakt}! (faktoriális) értéke: {faktorialisEredmeny}");

//random szám kitalálás
Console.WriteLine($"\n");
int rszam;
while (true)
{
    Console.WriteLine($"{nev} gondolok egy számra 1 és 100 között, próbálja meg kitalálni 10 próbálkozásból! Mehet? (igen/nem)");
    string igen = Console.ReadLine().ToLower();
    if (igen == "igen")
    {
        Random rnd = new Random();
        rszam = rnd.Next(1, 101);
        int probalkozas = 0;
        while (probalkozas < 10)
        {
            Console.WriteLine("Írja be a tippjét: ");
            string tipp = Console.ReadLine();
            if (int.TryParse(tipp, out int tippSzam))
            {
                probalkozas++;
                if (tippSzam < rszam)
                {
                    Console.WriteLine("Túl alacsony!");
                }
                else if (tippSzam > rszam)
                {
                    Console.WriteLine("Túl magas!");
                }
                else
                {
                    Console.WriteLine($"Gratulálok {nev}, kitalálta a számot {probalkozas} próbálkozásból!");
                    break;
                }
            }
            else
            {
                Console.WriteLine("Kérem, csak számot adjon meg!");
            }
        }
        if (probalkozas == 10)
        {
            Console.WriteLine($"Sajnos elfogytak a próbálkozásai. A szám, amire gondoltam: {rszam}");
        }
        break;
    }
    else if (igen == "nem")
    {
        Console.WriteLine("Rendben, legközelebb talán!");
        break;
    }
    else
    {
        Console.WriteLine("Kérem válaszoljon 'igen' vagy 'nem'!");
    }
}

Console.WriteLine($"\n");