﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _12._08otthongyak2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hány darab fájlt szeretne beolvasni: ");
            int db = Convert.ToInt32(Console.ReadLine().Trim());
            string[] tomb = Beker(db);
            Leghosszabb(tomb);
            Kepek(tomb);
        }

        static string[] Beker(int db)
        {
            string[] tomb = new string[db];
            int pont;
            for (int i = 0; i < db; i++)
            {
                do
                {
                    Console.WriteLine($"Írja be a(z) {i + 1} fájlnevet kiterjesztéssel: ");
                    tomb[i] = Console.ReadLine().Trim().ToLower();
                    pont = tomb[i].LastIndexOf('.');
                    if (tomb[i].Length - (pont + 1) != 3 || pont == -1) Console.WriteLine("Nem megfelelő a fájlnév! Próbálja újra!");
                } while (pont == -1 || tomb[i].Length - (pont + 1) != 3);


            }
            return tomb;
        }

        static void Leghosszabb(string[] tomb)
        {
            string hosszu = "";
            for (int i = 0; i < tomb.Length; i++)
            {
                if (tomb[i].Length > hosszu.Length)
                    hosszu = tomb[i];
            }
            Console.WriteLine($"A leghosszabb fájlnév: {hosszu}");
        }

        static void Kepek(string[] tomb)
        {
            List<string> keptipusu = new List<string>();
            int db = 0;
            for (int i = 0; i < tomb.Length; i++)
            {
                int pont = tomb[i].LastIndexOf('.');
                if (pont != -1)
                {
                    string kiterjesztes = tomb[i].Substring(pont + 1);
                    switch (kiterjesztes)
                    {
                        case "jpg":
                        case "png":
                        case "gif":
                            keptipusu.Add(tomb[i]);
                            break;
                    }
                } 
            }

            string hosszu = "";
            foreach(string h in keptipusu)
            {
                if (h.Length > hosszu.Length)
                    hosszu = h;
            }
            Console.WriteLine($"A leghosszabb kép fájlnév: {hosszu}");

            if (keptipusu.Count > 0)
            {
                Console.WriteLine("Talált képfájlok:");
                foreach (string fajl in keptipusu)
                {
                    Console.WriteLine(fajl);
                    db++;
                }
               
            }
            else
            {
                Console.WriteLine("Nincs képfájl a listában.");
            }
            Console.WriteLine($"Ennyi darab képfájl van: {db}");

            
        }

    }
    
}
