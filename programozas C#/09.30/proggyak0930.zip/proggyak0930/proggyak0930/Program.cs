﻿//WHILE  előtesztelő ciklus
/*
//írjuk ki a számokat 1-től 10-ig
int n = 1;
//amíg n értéke kisebb mint 11
while (n <= 10)
{ Console.WriteLine(n); 
 n++; // +=1; // n=n+1
}

//2. írjuk ki a számokat 10-től 1-ig
int m = 10;
//amíg  m értéke nagyobb vagy =, mint 1
while (m>=1)
{ Console.WriteLine(m);
    m--; //m-=1; // m=m-1;
}
*/
//3.írjuk ki az első 20 páros számot

/*
int n = 0;

while (n <= 20)
{
    if (n % 2 == 0) //páros szám
    {
        Console.WriteLine(n);
    }
    n++;
}
*/

//4.írjuk ki az első 10 páros számot (elágazás nélkül, hatékonyabb verzió)
/*int n = 0;

while (n <= 10)
{
   Console.WriteLine(n);
   n += 2; //n=n+2;
}
*/
//kérjük be a felhazsnálótól a 0 végjelig értéket (ha beírja  a 0-át akkor megáll a rendszer)
/*
int SZAM =-1;
// addig ismételje meg a szám változó értéke nem egyenlő 0-val
while (SZAM !=0)
{ Console.WriteLine("Kérek egy számot! ");
    SZAM = Convert.ToInt32(Console.ReadLine());
    Console.WriteLine($" A beírt szám: {SZAM}");
}*/

//írjuk ki a számokat 20-tól 10-ig csökkenő sorrendben
/*int sz = 20;
while (sz>= 10)
{ Console.WriteLine(sz);
    sz -= 1;
}
*/

//DO_WHILE kérjük be a számokat 0 végjelig (utótesztelő ciklus)
/*
int szam;
do { Console.WriteLine("Írd be egy számot: ");
    szam = Convert.ToInt32(Console.ReadLine());
    Console.WriteLine($" A bekért szám : {szam}");
}
while (szam != 0);
*/

//addig kell bekérni a nevet amíg az üres stringet ír be a felhasználó
/*
using System.Diagnostics.Tracing;

string név;
do
{
    Console.WriteLine("Írja be a nevétt: ");
    név = Console.ReadLine();
    Console.WriteLine($"Az ön neve: {név}");
}
while ( név.Equals("")); *///stringek esetében a string.equals() -> a == operáorok primitíveknél

//kérjünk be a usertől számokat de csak 1-7-ig fogadjunk el majd írjuk ki switchben szerkezettel hohy hétvége /hétköznap van
/*
int nap;
do
{
    Console.WriteLine("Kérek egy számot: ");
    nap = Convert.ToInt32(Console.ReadLine());
}
while (nap < 1 || nap > 7); //mindig azt fogalmazom meg amit nem fogadok el
switch (nap)
{ case 1: case 2: case 3: case 4: case 5:
        Console.WriteLine("Hétköznap"); break;
    case 6: case 7:
            Console.WriteLine("Hétvége"); break;
}

*/
// kérj be egy számot és írj ki annyi: XO -t egymás mellé és a szám nem lehet kisebb mint 1
/*
int db;

do
{
    Console.WriteLine("Írj be egy számot: ");
    db = Convert.ToInt32(Console.ReadLine());
}
while (db < 1);

while (db  >0)
{ Console.Write("xo");
    db--;
}
*/
//kérj be egy számot, a kapott számot írd ki csökkenő sorrendben pl: 5, 4, 3, 2, 1, 0
/*
Console.WriteLine("Válasszon egy számot: ");
int szam = Convert.ToInt32(Console.ReadLine());
while (szam > -1)
{ Console.WriteLine($"{szam}"); //valami rÓsz
    szam = szam - 1;
}
*/
// break vs continue kulcsszavak

/*int n = 0;
//true = végtelen ciklus -> kell kilépési feltétel
while (true)
{ n++;
    if (n % 2 == 1)
    { continue; } //páratlanokat átugorjuk
    Console.WriteLine(n);
    if (n >= 10) break; //ha 10 az n értéke -> kilépek
}
*/
//bemenet validálás
int n;
while (true)
{ Console.WriteLine("Kérek egy egész számot: ");
    if (int.TryParse(Console.ReadLine(),out n)) { break; }

    Console.WriteLine("Nem egész szám kérem próbálja meg újra!");
}
Console.WriteLine("Köszi:'D");

