﻿Console.WriteLine("Írja be a nevét: ");
string nev = Console.ReadLine();
Console.WriteLine($"Kedves {nev} hány kg almát szeretne vásárolni, ha az alma ára 400 FT/kg?");
double almaKg = Convert.ToDouble( Console.ReadLine());
double almaÁr = 400;
double almaÖsszes = almaKg * almaÁr;
Console.WriteLine($"Ha {almaKg} kg almát szeretne vásárolni, ami {almaÖsszes} forintba kerül.");

Console.WriteLine("\n");
Console.WriteLine("Írja be azt a Celsius fokot, amit Fahrenheitre szeretne váltani: ");
double C = Convert.ToDouble(Console.ReadLine());
double F = C * 9 / 5 + 32;
Console.WriteLine($"{C} celsius fok az {F} Fahrenheit");

Console.WriteLine("\n");
Console.WriteLine("Mondja meg hány gramm legyen a vödör és megmondom\nhány fecske tudná elcipelni: ");
double gramm = Convert.ToInt32(Console.ReadLine());
double fecskeGr = 60;
double fecskeErő = fecskeGr / 3;
double cippel = gramm / fecskeErő;
Console.WriteLine($"{gramm} grammú vödröt összesen {cippel} fecske tud elcipelni");

Console.WriteLine("\n");
Console.WriteLine("Most adja meg a fecskék számát és megmondom,\nmilyen nehéz vödröt tudnának elcipelni:");
double fecskeSzám = Convert.ToDouble(Console.ReadLine());
double cipel2 = fecskeSzám * fecskeErő;
Console.WriteLine($"{fecskeSzám} fecske összesen {cipel2} gramm nehéz\nvödröt tud elcipelni");

