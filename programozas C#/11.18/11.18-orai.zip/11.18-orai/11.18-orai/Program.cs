﻿using System.Data.SqlTypes;
using System.Net.Http.Headers;
using System.Reflection.Metadata;
using System.Reflection.Metadata.Ecma335;
using System.Runtime.InteropServices;

namespace _11._18_orai
{
    internal class Program /* classon belül hozzuk létre a metódusokat*/
    {
        static void Main(string[] args) // staticot mindig ki kell írni
        {
            // Hello();
            // NevKiir("Tita");
            // Console.WriteLine(Osszead(3,5));
            // Console.WriteLine($"A neved: {Beker()}");
            // Udvozles();
            /* int a = Szambeker();
             int b = Szambeker();
             int eredmeny = Osszead(a, b);
             Console.WriteLine(eredmeny); */
            //Console.WriteLine("Az eredmény: " + Osszead(Szambeker(), Szambeker()));

            //3.
            // int[] szamok = Beolvas();
            /*int osszeg = Osszead(szamok);
            int szorzas = Szoroz(szamok);
            int atlag = Atlagol(szamok);
            Kiir(osszeg, atlag, szorzat)*/
            //Var(Osszead(szamok), Atlagol(szamok), Szoroz(szamok));

            //teglalpos
            /*int a = Beolvas("A");
            int b = Beolvas("B");
           /* int kerulet = Kerulet(a, b);
            int terulet = Teruklet(a, b);
            Kiir(kerulet, terulet);*/
            //Kiir(Kerulet(a, b), Teruklet(a,b));
            //5.
            /*string mondat = Beolvas();
            int generalt = Generalt();
            string osszezagyval = Osszezagyval(generalt, mondat);
            Kiir(osszezagyval);*/
           // Kiir(Osszezagyval(Generalt(), Beolvas()));
            Kiir(Osszezagyval(MaganhangzoBe(), Beolvas()));

            int x=23;
            Szamol(x);
        }
        static void Szamol(int z)
        { z = z + 6;
            Console.WriteLine(z);
        }

        /*
        static void Hello()
        { Console.WriteLine("Helló metódus!"); }

        static void NevKiir(string nev)
        { Console.WriteLine($"Szia, {nev}"); }

        static int Osszead(int a, int b)
        { return a + b;  }

        //kérjünk be a usertől a nevét
        static string Beker()
        { Console.WriteLine("Írd be a neved");
            return Console.ReadLine(); //ezt külön változóba is bele lehet tenni és aztán return
        }*/

        //2. metódusos program
        /* static void Udvozles()
         { Console.WriteLine("Ez egy összeadó program"); }
         static int Szambeker()
         { Console.WriteLine("Adjon meg egy számot:");
             return int.Parse(Console.ReadLine()); }
         static int Osszead(int a, int b)
         { return a + b; } */

        //3.feladat
        /*static int[] Beolvas()
        {
            int[] szamok = new int[5];
            for (int i = 0; i < szamok.Length; i++)
            {
                Console.WriteLine($"Kérem az {i + 1}.számot");
                szamok[i] = int.Parse(Console.ReadLine());
            }
            return szamok;
        }

        //osszead=(->vár egy int tömböt visszatér egy int-el
        static int Osszead(int[] oszam)
        {
            int osszeg = 0;
            foreach (int szam in oszam)
            { osszeg += szam; }
            return osszeg;
        }

        //átlagol()- int[] tömb, inttel tér vissza
        static int Atlagol(int[] aszam)
        {
            int osszeg = Osszead(aszam);
            int atlag = osszeg / aszam.Length;
            return atlag;

            /*int osszeg = 0;
            foreach (int szam in aszam)
            { osszeg += szam; }
            int atlag = osszeg / aszam.Length;
            return atlag;}*/ //ez is jó 
        /*}

        //szoroz int[], int szám
        /*static int Szoroz(int[] szszsam)
        {
            int szorzas = 1;
            foreach (int sz in szszsam)
            { szorzas *= sz; }
            return szorzas;
        }

        //kiir, nincs visszateres, 3 db változót vár
        //konzolra kiirja a számok összeget
        static void Var(int osszeg, int atlag, int szorzat)
        {
            Console.WriteLine($"A számok összege, szorzata, átlaga: {osszeg}, {szorzat}, {atlag}");
        }*/

        //téglalap kerület és terület
        /* static int Beolvas(string oldal)
         { Console.WriteLine($"Add meg az {oldal} oldalt");
             return int.Parse(Console.ReadLine());
         }
         static int Kerulet(int a, int b)
         { return 2 * (a + b); }
         static int Teruklet(int a, int b)
         { return a * b; }
         static void Kiir(int kerulet, int terulet)
         {Console.WriteLine($"Kerület: {kerulet} m"); 
         Console.WriteLine($"Terület: {terulet} m2"); }*/

        //5.Összezagyváló program
        //Beolvas() stringgel tér vissza
        static string Beolvas()
        { Console.WriteLine("Írjon egy tetszőleges szöveget: ");
            return Console.ReadLine(); 
        }
        // semmit nem vár visszA int-tel tér vissza
        /*static int Generalt()
        { Random rnd = new Random();
            return rnd.Next(0,14);
        }*/
        //összezagyválás
        static char MaganhangzoBe()
        {  Console.WriteLine("Válasszon egy magánhangzót:");
            return Console.ReadLine()[0];
        }
        static string Osszezagyval(char betu, string mondat)
        {
            char[] maganh = { 'a', 'á', 'e', 'é', 'i', 'í', 'o', 'ó', 'ö', 'ő', 'ü', 'ű', 'u', 'ú' };
            char[] zagyva = mondat.ToCharArray();
            for (int i = 0; i < zagyva.Length; i++)
            {
                if (Array.IndexOf(maganh, zagyva[i]) != -1)
                { zagyva[i] = maganh[betu]; }

            }
            return new string(zagyva);
        }

        static void Kiir(string mondat)
        { Console.WriteLine(mondat); }
        /*
        static string Osszezagyval(int rnd, string mondat)
        {      char[] maganh = { 'a', 'á', 'e', 'é', 'i', 'í', 'o', 'ó', 'ö', 'ő', 'ü', 'ű', 'u', 'ú' };         
            char[] zagyva = mondat.ToCharArray();
            for (int i = 0; i < zagyva.Length; i++)
            {
                    if (Array.IndexOf(mgh, zagyva[i]) != -1)
                    { zagyva[i] = maganh[rnd]; }
              
            }
            return new string(zagyva);
        }

        static void Kiir(string mondat)
        { Console.WriteLine(mondat); }
        */

    }
}
