﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace gpt_adta_feladat_2
{
    public struct Konyvtar
    {
        public string KeresztNev, Mufaj, Allapot;
        public int SorSzam, IdoTartam;
    }

    public struct Kolcsonzes
    {
        public string KeresztNev;
        public int OsszKolcs;
    }
    internal class Program
    {
        static int z = 0;
        static Konyvtar[] konyvek = new Konyvtar[40];
        static Kolcsonzes[] kolcson = new Kolcsonzes[40];

        static bool Beolvas()
        {
            try
            {
                StreamReader konytar_csv = new StreamReader("konyvtar.csv", Encoding.Default);
                while (!konytar_csv.EndOfStream)
                {
                    string[] darab = konytar_csv.ReadLine().Split(';');
                    konyvek[z].KeresztNev = darab[0];
                    konyvek[z].SorSzam = int.Parse(darab[1]);
                    konyvek[z].Mufaj = darab[2];
                    konyvek[z].IdoTartam = int.Parse(darab[3]);
                    konyvek[z].Allapot = darab[4];
                    z++;
                }
                konytar_csv.Close();
                Console.WriteLine("0.Feladat\nA fájbeolvasás sikeres volt!");
                return true;
            }catch ( Exception hiba)
            { Console.WriteLine("0.Feladat\nFájlbeolvasás közben hiba történt! " + hiba.Message);
                return false;
            }
        }

        static bool Kiir()
        {
            int t;
            int u = 0;
            bool jo;
            for (int i = 0; i < z; i++)
            {
                jo = false;
                for (t = 0; t < u; t++)
                {
                    if (konyvek[i].KeresztNev == kolcson[t].KeresztNev)
                    {
                        jo = true;
                        kolcson[t].OsszKolcs++;
                        break;
                    }
                    if (!jo)
                    { 
                        kolcson[u].KeresztNev = konyvek[i].KeresztNev;
                        kolcson[u].OsszKolcs = 1;
                        u++;
                    }
                }
            }

            try
            {
                StreamWriter olvasok_txt = new StreamWriter("olvasok.txt", false, Encoding.Default);
                for (t = 0; t < u; t++)
                {
                    olvasok_txt.WriteLine(kolcson[t].KeresztNev + " " + kolcson[t].OsszKolcs);
                }
                olvasok_txt.Close();
                Console.WriteLine("4.Feladat\nFájlkiírás sikeres!");
                return true;

            } catch (Exception Hiba)
            { Console.WriteLine("4.Feladat\nFájlkiírás közben hiba történt! "+ Hiba.Message);
                return false;
            }
        }


        static void Main(string[] args)
        {
            if (Beolvas())
            {
                int legtovabb = int.MinValue;
                Konyvtar legtobb = new Konyvtar();
                for (int i = 0; i < z; i++)
                {
                    if (konyvek[i].IdoTartam > legtovabb)
                    {
                        legtovabb = konyvek[i].IdoTartam;
                        legtobb = konyvek[i];
                    }
                }
                Console.WriteLine($"1.Feladat\nA leghosszabb kölcsönzés: {legtobb.KeresztNev}, {legtobb.SorSzam}. kölcsönzés, {legtobb.IdoTartam} nap.");

                Console.WriteLine("Írja be a nevet: ");
                string kapNev = Console.ReadLine().Trim();
                int db = 0;
                int ido = 0;
                for (int i=0; i<z;i++)
                {
                    if (kapNev == konyvek[i].KeresztNev)
                    {
                        db++;
                        ido += konyvek[i].IdoTartam;
                    }
                }
                if (db != 0)
                {
                    Console.WriteLine($"2.Feladat\n{kapNev} összesen {ido} napig kölcsönzött.");
                }
                else
                {
                    Console.WriteLine("2.Feladat\nIlyen nevű olvasó nem szerepel az adatokban!");
                }

                int ujDB = 0, ujOssz = 0;
                int haszDB = 0, haszOssz = 0;
                for (int i = 0; i < z; i++)
                {
                    if (konyvek[i].Allapot == "uj")
                    {
                        ujDB++; ujOssz += konyvek[i].IdoTartam;
                    }
                    if (konyvek[i].Allapot == "hasznalt")
                    {
                        haszDB++; haszOssz += konyvek[i].IdoTartam;
                    }
                }
                Console.WriteLine($"3.Feladat\nAz új könyvek átlagos kölcsönzési ideje: {Math.Round((double)ujOssz/ujDB,0)}\n" +
                    $"A használt könyvek átlagos kölcsönzési ideje: {Math.Round((double)haszOssz/haszDB,0)}");
            



            }
            if (Kiir())
            { }
            else
            {
                Console.WriteLine("Viszlát!");
            }
            Console.ReadKey();
        }
    }
}
