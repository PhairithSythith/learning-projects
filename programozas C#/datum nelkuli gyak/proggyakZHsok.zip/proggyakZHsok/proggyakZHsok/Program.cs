﻿/*
//Kérjünk be 5 számot, minden bekérésnél legyen sorszám
int n = 0;
int[] bekert = new int[5];
do
{
    Console.WriteLine("Kérem az "+n+".számot ");
    bekert[n] = Convert.ToInt32(Console.ReadLine());
    n++;

} while (n< bekert.Length);
Console.WriteLine("A bekérés sorrendje: ");
//írjuk ki visszafele
foreach (int b in bekert)
{
    Console.Write(b+ ",");
}
Console.WriteLine();
Console.Write(" Visszafele:");

for (int i = bekert.Length -1; i >=0; i--)
{
    Console.Write(bekert[i]+ ",");
}

Console.WriteLine();
//random dobjunk 1-6, dobasok száma
int[] dobas = new int[10];
Random rnd = new Random();
int[] mennyi = new int[6];
int osszeg = 0;
int szam=0;

for (int i = 0; i < 10; i++)
{
    int dob = rnd.Next(1,7);
    dobas[i] = szam;
    osszeg += szam;
}
// dobások 
for(int dob=1;dob<7;dob++)
{
    for (int i = 0; i < dobas.Length; i++)
    { if (dob == dobas[i])
        {
            mennyi[dob - 1] += 1;
        }
    }
}
Console.WriteLine("Dobások: ");
//dobások átlaga
for (int i = 0, x = 1; i < mennyi.Length; i++, x++)
{
    Console.WriteLine(x + "-ból/-ből: " + mennyi[i] + "db.");
}
Console.WriteLine("A dobások átlaga:" + (osszeg / dobas.Length));

//kérjünk be egy szöveget

Console.WriteLine("Írjon be egy tetszőleges szöveget:");
string szoveg = Console.ReadLine().ToLower();
char[] sz = szoveg.ToCharArray();
char[] abc = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm',
'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z' };

int[] abc2 = new int[abc.Length];
foreach (char s in sz)
{ for (int i = 0; i < abc2.Length; i++)
    {
        if (s == abc[i])
        {
            abc2[i] += 1;
        }
    }
}
Console.WriteLine("Eredmény:");
for (int i = 0; i < abc2.Length; i++)
{
    Console.WriteLine(abc[i] + ": " + abc2[i] + "db");
}
*/

//kérjünk be 25-40 között számot
int szam = 0;
int osszeg = 0;
do
{
    Console.WriteLine("Adjon meg egy számot 25-40 között: ");
    szam = Convert.ToInt32(Console.ReadLine());
}while(szam<=25 || szam>=40);
Random rnd = new Random();
szam = rnd.Next(2,6);
int harmad = (int)Math.Round((double)szam/3);
int[] szamok = new int[harmad];
for (int i = 0; i < szamok.Length; i++)
{
    szamok[i] = rnd.Next(-100,101);
}
Console.WriteLine($"A tömb elemeinek átlaga: {szamok.Average():F2}");

int veletlen = rnd.Next(0, szamok.Length);
int relem = szamok[veletlen];
Console.WriteLine($"A random index alapján kiválasztott elem: {relem}");


for (int i = 0; i < szamok.Length; i++)
{
    szamok[i] = szamok[i] + i * 2;
}
Console.WriteLine($"A számokhoz hozzáadott tömidex*2: {string.Join(",",szamok)}");
int negativ=0;
foreach(int sz in szamok)
{
    if (sz<0)
    { negativ = negativ + Math.Abs(sz); }
}
Console.WriteLine($"Ennyit kell hozzáadni hogy ne legyen negatív: {negativ}");
Console.ReadKey();