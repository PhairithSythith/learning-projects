﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace otthongyak11._28
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(Eletkor(2003));
            HackerIrasmod("Mivan veled szopadék kiütlek a gecibe");



            Console.ReadKey();
        }

        static int Eletkor(int eletkor)
        { return 2025 -eletkor; }

        static void HackerIrasmod(string szoveg)
        {   char[] atalakito = szoveg.ToCharArray();
            for (int i = 0; i < szoveg.Length; i++)
            {
                switch (atalakito[i])
                {
                    case 'l': atalakito[i] = '1'; break;
                    case 'o': atalakito[i] = '0'; break;
                    case 'e': atalakito[i] = '3'; break;
                    case 's': atalakito[i] = '5'; break;
                    case 'ó': atalakito[i] = '6'; break;
                    case 't': atalakito[i] = '7'; break;
                    case 'g': atalakito[i] = '9'; break;
                    default:atalakito[i] = szoveg[i]; break;
                }
               
            }
            Console.WriteLine(new string(atalakito));
        }
    }
}
