﻿//1.feladat :
int szam;
do {
    Console.WriteLine("Kérek egy 25 és 40 közötti számot: ");
    szam = Convert.ToInt32(Console.ReadLine());
} while (szam<25 || szam>40); //amit nem fogadunk el || (vagy-nál)
//szorozzuk meg 2 és 5 közötti random számmal
Random rnd = new Random();
szam = szam * rnd.Next(2, 6);
//tömb hossza a szám harmada legyen
int harmad =(int)Math.Round((double) szam / 3); //Math.Floor() - mindig lefele, Math.Ceil()- mindig felfele, Math.Round a kerekítés szabályainak megfelelően kerekít
int[] szamok = new int[harmad];
//töltsük fel a tömböt
for (int i = 0; i < szamok.Length; i++)
{
    szamok[i] = rnd.Next(-100, 101);
}
//átlag
Console.WriteLine($"A számok átlaga: {szamok.Average()}");

//2.feladat Véletlen index generáláás és aaz elem kiválasztása
int vidx = rnd.Next(0, szamok.Length);
int elem = szamok[vidx];
Console.WriteLine($"Véletlen indexű elem: {elem}");

//3.feladat tömbindex kétszeresének hozzáadása adott elemhez
for (int i = 0; i < szamok.Length; i++)
{
    szamok[i] = szamok[i] + i * 2;
}
//ellenőrzés magamnak hogy előtte és utánna is kiírathatom

//4.feladat
int negativ = 0;
foreach (int sz in szamok)
{ 
if (sz<0)
    { negativ = negativ + Math.Abs(sz);
    }
}
Console.WriteLine($"Összesen ennyit kellene hozzáadni: {negativ}");