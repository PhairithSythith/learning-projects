﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace gpt_adta_feladat
{ public struct Bowling
    {
        public string jatekosNeve, jatekTipus;
        public byte forduloSzam, palyaszam;
        public int pontszam;
    }
    public struct Jatekosok
    { public string jatekosNeve;
        public int pontszam;
    }
    internal class Program
    {
        static int r = 0;
        static Bowling[] jatszas = new Bowling[40];
        static Jatekosok[] kettoadat = new Jatekosok[40];

        static bool Beolvas()
        {
            try
            {
                StreamReader bowling_csv = new StreamReader("bowling.csv", Encoding.Default);
                while (!bowling_csv.EndOfStream)
                { string[] darabok = bowling_csv.ReadLine().Split(';');
                    jatszas[r].jatekosNeve = darabok[0];
                    jatszas[r].forduloSzam = byte.Parse( darabok[1]);
                    jatszas[r].palyaszam = byte.Parse(darabok[2]);
                    jatszas[r].jatekTipus = darabok[3];
                    jatszas[r].pontszam = int.Parse(darabok[4]);
                    r++;
                }
                bowling_csv.Close();
                Console.WriteLine("0.Feladat\nAz adatok beolvasása megtörtént!");
                return true;
            } catch (Exception hiba)
            { Console.WriteLine("0.Feladat\nA fájl beolvasása közben hiba történt. " + hiba.Message);
                return false;
            }
        }

        static bool Kiir()
        {
                int u;
                int k = 0;
                bool van;
                for (int i = 0; i < r; i++)
                {
                    van = false;
                    for (u = 0; u < k; u++)
                    { if (jatszas[i].jatekosNeve == kettoadat[u].jatekosNeve)
                        { van = true;
                            break;
                        }
                    }
                    if (van)
                    {
                        kettoadat[u].pontszam += jatszas[i].pontszam;
                    }
                    else { kettoadat[k].jatekosNeve = jatszas[i].jatekosNeve;
                        kettoadat[k].pontszam = jatszas[i].pontszam;
                        k++;
                    }
                    
                }

            try
            {
                StreamWriter jatekosok_txt = new StreamWriter("jatekosok.txt", false, Encoding.Default);
                for (u = 0; u < k; u++)
                { jatekosok_txt.WriteLine($"{kettoadat[u].jatekosNeve} {kettoadat[u].pontszam} pont"); }
                jatekosok_txt.Close();
                return true;
            } catch (Exception hiba)
            { Console.WriteLine(hiba.Message);
                return false;
            }
        }

        static void Main(string[] args)
        {
            if (Beolvas())
            {
                int legn = int.MinValue;
                Bowling legnagyobb = new Bowling();
                for (int i = 0; i < r; i++)
                {
                    if (jatszas[i].pontszam > legn)
                    {
                        legn = jatszas[i].pontszam;
                        legnagyobb=jatszas[i] ; }
                }
                Console.WriteLine($"1.Feladat\nA legnagyobb pontszámot {legnagyobb.jatekosNeve} érte el a  {legnagyobb.forduloSzam} fordulóban {legnagyobb.pontszam} ponttal.");

                Console.WriteLine("Írja be egy játékos nevét: ");
                string kapottNev = Console.ReadLine().Trim();
                byte db = 0;
                for (int i = 0; i < r; i++)
                { if (jatszas[i].jatekosNeve ==kapottNev)
                     db++; 
                }
                if (db != 0)
                    Console.WriteLine($"2.Feladat\n{kapottNev} nevű játékos összesen {db} fordulóban játszott.");
                else Console.WriteLine("Ilyen nevu jatekos nem volt a versenyen!");

                    int amatordb = 0, amatorOssz = 0;
                int profidb = 0, profiOssz = 0;
                for (int i = 0; i < r; i++)
                { if (jatszas[i].jatekTipus == "Amator")
                    {
                        amatordb++;
                        amatorOssz += jatszas[i].pontszam;
                    }
                    else  if (jatszas[i].jatekTipus == "Profi")
                    { profidb++;
                        profiOssz += jatszas[i].pontszam;
                    } 
                }
                Console.WriteLine($"3.Feladat\nAz amatőr játéktípusnál az átlagosan elért pontszámok: {Math.Round((double)amatorOssz/amatordb,0)}" +
                    $" a profi játéktípusnál átlagosan elért pontszámok pedig: {Math.Round((double)profiOssz/profidb,0)} ");



            }
            if (Kiir())
            { Console.WriteLine("4.Feladat\nAz adatok kiírása megtörtént!"); }
            else { Console.WriteLine("Viszlát"); }
            Console.ReadKey();
            
        }
    }
}
