﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace _11._25oraigyak
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /*
            //Fájlkezelés
            //Fájlba írás
            StreamWriter sw = new StreamWriter(@"C:\Users\ritzo\Desktop\Programozás\11.25\09_fajlkezeles\kalman.txt", true);
            //append =true->mindig új sort ad hozzá a txt 
            // írjunk egy sort a fájlba
            sw.WriteLine("Ez egy üzenet Kálmánnak");
            //még egy sort írhatunk
            sw.WriteLine("Kálmán, KaKálmán");
            //mindig le kell zárni a fájlt!!!!
            sw.Close();
            */
            //Fájlbeolvasás
            // StreamReader sr = new StreamReader(@"C:\Users\ritzo\Desktop\Programozás\11.25\09_fajlkezeles\kalman.txt");
            /*Console.WriteLine(sr.ReadLine());
            Console.WriteLine(sr.ReadLine());
            Console.WriteLine(sr.ReadLine());
            Console.WriteLine(sr.ReadLine());
            Console.WriteLine(sr.ReadLine());
            Console.WriteLine(sr.ReadLine());
            Console.WriteLine(sr.ReadLine());
            Console.WriteLine(sr.ReadLine());*/


            //addig
            /*while(!sr.EndOfStream)
            { Console.WriteLine(sr.ReadLine()); }

            sr.Close(); */
            //generálj 20-50 között számot
            //ez lesz a txt fájlokban a sorok száma
            //utána generáljunk minden sorba 100-500 közötti számot
            /*StreamReader sa = new StreamReader(@"C:\Users\ritzo\Desktop\Programozás\11.25\09_fajlkezeles", true); //false->mindig új számot generál 
            Random rnd = new Random();
            int sorok = rnd.Next(20,51);

            for (int i = 0; i < sorok; i++)
            { sa.WriteLine(rnd.Next(100, 501)); }

            sa.Close();*/

            /*StreamReader sw = new StreamReader(@"C:\Users\ritzo\Desktop\Programozás\11.25\09_fajlkezeles\veletlen.txt");
            int osszeg = 0, db = 0;
            while (!sw.EndOfStream)
            { osszeg += Convert.ToInt32(sw.ReadLine());
                db++;
            }
            sw.Close();
            Console.WriteLine($"Az összeg: {osszeg}, a sorork: {db}");*/

            //olvassuk be nevek2.txt egy tömbbe 
            //írjuk ki minden második tömbelemet
            //a tömb hossza a nevek db száma a fájl 1 sora
            /* StreamReader sr = new StreamReader(@"C:\Users\ritzo\Desktop\Programozás\11.25\09_fajlkezeles\nevek2.txt", true);
             int hossz = Convert.ToInt32(sr.ReadLine());
             string[] nevek = new string[hossz];
             int n = 0;
             while (!sr.EndOfStream)
             { nevek[n] = sr.ReadLine(); }
             sr.Close();

             for (int i=0, j=1;i<nevek.Length;i+=2,j++)
             { Console.WriteLine($"{j}. {nevek[i]}"); }
            */

            //a nevek3.txt olvassuk be és írjuk ki a C betűvel kezdődő neveket
            /* StreamReader cnev = new StreamReader(@"C:\Users\ritzo\Desktop\Programozás\11.25\09_fajlkezeles\nevek3.txt");
             while(!cnev.EndOfStream)
             { string nev= cnev.ReadLine();
                 //if(nev.StartsWith("C"))
                 /*if (nev[0].Equals("C"))
                 { Console.WriteLine(nev); }*/
            /* if (nev.Length >= 12)
             { Console.WriteLine(nev); }
         }
         cnev.Close();
            */


            //gondoltam 1 számra játék
                     
            




            //Console.ReadKey();
     
        }
        /*
        static int General()
        { Random rnd = new Random();
            return rnd.Next(1, 21);
        }

        static int Tipp()
        { Console.WriteLine("Kérek egy számot (1-20):");
            return int.Parse(Console.ReadLine());
        }
        static void Jatek()
        {
            Console.WriteLine("Gondoltam egy számra....");
            int szam = General();
            int tipp = 0, probalkozas = 0;

            while (tipp != szam)
            {
                tipp = Tipp();
                if (tipp < szam)
                { Console.WriteLine("A gondolt szám nagyobb"); }
                else if (tipp > szam) { Console.WriteLine("A gondolt szám kisebb"); }
                probalkozas++;
            }

            Kiir(probalkozas, szam);
        }

            static void Kiir(int tippek, int megoldas)
            {
                Console.WriteLine($"Gratulálok! A számot {tippek} db. próbálkozásból találtad ki!");
                Console.WriteLine($"A gondolt szám: {megoldas}");
            }
        */
        



    }

}
