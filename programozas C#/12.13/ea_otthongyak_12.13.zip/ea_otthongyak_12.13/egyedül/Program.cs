﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace egyedül
{
    public struct Minden
    {
        public string nev, tipus;
        public byte asztal, fordulo;
        public int nyeremeny;
    }
    public struct Legnagyobb
    {
        public string nev;
        public int nyeremeny;
    }
    internal class Program
    {
        static int x = 0;
        static Minden[] mindenis = new Minden[40];
        static Legnagyobb[] legnagyobbis = new Legnagyobb[40];

        static bool Beolvas()

        {
            try
            {
                StreamReader poker_csv = new StreamReader("poker.csv");
                while (poker_csv.EndOfStream)
                {
                    string[] darab = poker_csv.ReadLine().Split(';');
                    mindenis[x].nev = darab[0];
                    mindenis[x].fordulo = byte.Parse(darab[1]);
                    mindenis[x].asztal = byte.Parse(darab[2]);
                    mindenis[x].tipus = darab[3];
                    mindenis[x].nyeremeny = int.Parse(darab[4]);
                    x++;

                }
                poker_csv.Close();
                Console.WriteLine("Az adatok beolvasása megtörtént");
                return true;

            }
            catch (Exception hiba)
            {
                Console.WriteLine("Hiba történt" + hiba.Message);
                return false;
            }
        }

        static bool Kiir()
        {
            int z;
            int t = 0;
            bool megvan;
            for (int i = 0; i < x; i++)
            {
                megvan = false;
                for (z = 0; z < t; z++)
                {
                    if (mindenis[i].nev == legnagyobbis[z].nev)
                        megvan = true;
                    break;
                }
                if (megvan)
                {
                    legnagyobbis[t].nyeremeny += mindenis[i].nyeremeny;
                }
                else
                {
                    legnagyobbis[z].nev = mindenis[i].nev;
                    legnagyobbis[z].nyeremeny = mindenis[i].nyeremeny;
                    z++;
                }
            }
                try
                {
                    StreamWriter jatekos_txt = new StreamWriter("jatekos.txt");
                    for (z = 0; z < t; z++)
                    { jatekos_txt.WriteLine(legnagyobbis[z].nev, legnagyobbis[z].nyeremeny); 
                    }
                    jatekos_txt.Close();
                    return true;
                }catch (Exception hiba)
                {
                    Console.WriteLine(hiba.Message);
                    return false;
                }

            
        }

            static void Main(string[] args)
            {
            if (Beolvas())
            {
                int max = int.MinValue;
                Minden legjobb = new Minden();
                for (int i = 0; i < x; i++)
                {
                    if (mindenis[x].nyeremeny > max)
                        legjobb = mindenis[i];
                }
                Console.WriteLine("A legnagyobb nyereménye" + mindenis[x].nev + "-nek/nak volt" + legjobb + "FT");

                Console.WriteLine("2.Feladat\nÍrja be egy  játékos nevét: ");
                string kapottNev = Console.ReadLine().Trim();
                byte db = 0;
                for (int i = 0; i < x; i++)
                {
                    if (kapottNev == mindenis[i].nev)
                    { db++; }
                }
                if (db != 0)
                    Console.WriteLine($"{kapottNev} nevű játékos {mindenis[x].fordulo} fordulóban játszott");
                else Console.WriteLine("Ilyen nevű játékos nem volt a versenyen!");
                int texasDB = 0, texasO = 0;
                int otlapDB = 0, otlapO = 0;
                for (int i = 0; i < x; i++)
                {
                    if (mindenis[x].tipus == "Ötlapos póker")
                    {
                        otlapDB++;
                        otlapO += mindenis[x].nyeremeny;
                    }
                    else
                    {
                        texasDB++;
                        texasO += mindenis[x].nyeremeny;
                    }
                    Console.WriteLine($"Átlagos nyereméyn Texas Hold'em: {Math.Round((double)texasO / texasDB, 0)}\n" +
                        $"Átlagos nyeremény Ötlapos póker: {Math.Round((double)otlapO / otlapDB)}");
                }
                if (Kiir())
                { Console.WriteLine("Az adatok kírása megtörtént"); }
                else { Console.WriteLine("A kiírás közben hiba történt"); }
            }
            else Console.WriteLine("Viszontlátásra!");
            Console.ReadKey();
            }
        
    }
}
