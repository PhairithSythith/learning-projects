﻿// komment
/*
/* így 
 * írsz 
 * több
 * sororos
 * kommentet
 * */
/*
int g = 300;
byte c = (byte)g;
Console.WriteLine(c);

// explicit es implicit cast
//implicit : biztos nem veszit infot (kicsibol nagyba)
int z = 500;
long k = z;
Console.WriteLine(k);
//explicit : vallalom a  felelosseget hogy veszit infot
long o = 1000;
int d= (int) o;
Console.WriteLine(d);

string = "Titanilla";
char kukac = '@';
Console.WriteLine(kukac);   
*/

//egesz szzam torte alakitasa

//int egesz = 123;
//double tort = egesz +0.1;
//Console.WriteLine(tort);

//tort szamot egssze
/*
 * using System.Threading.Channels;

double pi = 3.14;
int csonkPi = (int)pi;
Console.WriteLine(csonkPi);
*/

//szoveg konvertalasa egessze

//string szulEv = "1998";
//int szulettem = int.Parse(szulEv);
//Console.WriteLine(szulettem);
/*
//szovegbol tortet
//string celsius = "27.3";
//ouble tegnapFok = 32.5;
// double maFok = 23.8;
//double maFok = Convert.ToDouble(celsius);
//Console.WriteLine(maFok);
//Console.WriteLine($"Ma {tegnapFok-maFok} C van");
// magyaro.-n tizedes pont helyett tizedes vesszo!!!!
*/

// string megjelenitesi modja
// konkatenacio <- ossuefuzes

//Console.WriteLine("Jánk"+ " " +"Titanilla");
//string keresztnev = "Titanilla" ;
//string nevem = $"Ma  {celsius} fok volt kint,";
//Console.WriteLine(celsius);

/* 
    string ezkamu = "true";
bool trueStory = Convert.ToBoolean(ezkamu);
Console.WriteLine(trueStory);

int evszam = 2025;
string evString = evszam.ToString();
string evString2 = Convert.ToString(evString);
Console.WriteLine(evString);
Console.WriteLine("Caesar mondja: \" A kocka el van vetve\"");
Console.WriteLine("MInden\nsor\núj\nsor");

Console.WriteLine("Ird be a neved!");
string userNew = Console.ReadLine();
Console.WriteLine($"A user neve {userNew}");
*/

/*
Console.WriteLine("Írd be a születési évszámodat: " );

string szultesiEv = Console.ReadLine();

int szulEvszam = Convert.ToInt32(szultesiEv);

int kor = 2025 - szulEvszam;

Console.WriteLine($"TE {kor} éves vagy (de nem biztos).");
*/

//öönallo kerjjuk be a  negyzet oldal  és szamoljuk ki a terultet T=a*a
Console.WriteLine("Ekkorák legyenek a négyzet oldalai: ");
string oldalHossz = Console.ReadLine();
int a = Convert.ToInt32(oldalHossz);
int oldH = a * a;

Console.WriteLine($" A négyzet területe \n(T): {oldH} mˇ2 "); 

