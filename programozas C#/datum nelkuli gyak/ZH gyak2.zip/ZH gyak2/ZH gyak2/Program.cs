﻿//1. generál 1-100 között számokat, tedd tömbbe, írd ki az összegüket és az átlagukat
using System;

int[] szamok = new int[10];
Random rnd = new Random();
int osszeg = 0;
for (int i = 0; i < szamok.Length; i++)
{
    szamok[i] = rnd.Next(1, 101);
    osszeg += szamok[i];
}
double atlag = (double)osszeg / szamok.Length;
Console.WriteLine($"A generált számok: {string.Join(",", szamok)}");
Console.WriteLine($"A számok összege: {osszeg}");
Console.WriteLine($"A számok átlaga: {atlag:F2}");
//2. az összeget mindig váltsa páratlan száma
int pozitiv=1;
foreach (int sz in szamok)
{
    if (sz != 0) ;
    { pozitiv = pozitiv + Math.Abs(sz); }
}

Console.WriteLine($"A pozitív számokhoz ennyit kell hozzáadni hogy negatív legyen: {pozitiv}");
//3. minden szám legyen negatív
int negativra =0;
foreach (int sz in szamok)
{
    if (sz > 0) ;
    { negativra = negativra + Math.Abs(sz)*2; }
}

Console.WriteLine($"Az elemek ezek lesznek ha negatívra alakítjuk őket: {negativra}");



Console.WriteLine("-------------------------------------------");
double[] negyzet = new double[15];
double[] gyok = new double[15];
int[] masikSzam = new int[15];
Random rnd2 = new Random();
for (int j = 0; j < masikSzam.Length; j++)
{   masikSzam[j] = rnd2.Next(1,51);
    gyok[j] = Math.Round(Math.Sqrt(masikSzam[j]), 2);
    negyzet[j] = masikSzam[j] * masikSzam[j];
    
    
}
int min = masikSzam.Min();
int max = masikSzam.Max();

Console.WriteLine($"Az elemek: {string.Join(",",masikSzam)}");
Console.WriteLine($"A generált elemek legkisebje: {min}, a legnaggyobja: {max}");
Console.WriteLine($"Az elemek négyzete: {string.Join(" ,",negyzet)}");
Console.WriteLine($"Az elemek gyöke: {string.Join("  ,  ", gyok)}");


Console.WriteLine("-------------------------------------------");
//csinááljunk egy tömböt 20 random számmal 1-200 között, nézzük meg melyikeke párosak és melyikeke páratlanok, írjuk ki őket
Random rnd3 = new Random();
double[] szamok2 = new double[20];
List<double> parosak2 = new List<double>();
List<double> negativak2 = new List<double>();
int pdb = 0;
int ndb = 0;

    for (int sz = 0; sz < szamok2.Length; sz++)
    {
        szamok2[sz] = rnd3.Next(1, 201);

    if (szamok2[sz] % 2 == 0) {
        pdb++;
        parosak2.Add((double)szamok2[sz]); }

    if (szamok2[sz] % 2 == 1) {
        ndb++;
        negativak2.Add((double)szamok2[sz]); }
}
    Console.WriteLine($"Az elemek: {string.Join(",", szamok2)}");
Console.WriteLine($"A páros elemek: {string.Join(",", parosak2)}, ennyi db van összesen: {pdb}");
Console.WriteLine($"A páratlan elemek: {string.Join(",", negativak2)}, ennyi db van összesen: {ndb}");


Console.WriteLine("-------------------------------------------");
//csináljunk egy tömböt random 12 számmal 10-99 között, nézzük meg hogy hány eleme osztható 3-al és mik azok
Random rnd4 = new Random();
int [] szamok3 = new int[12];
int oszthato = 0;
List<int> sorolas = new List<int>();
for (int k = 0; k < szamok3.Length; k++)
{
    szamok3[k] = rnd4.Next(10,100);
    if (szamok3[k] % 3 == 0)
    {
        oszthato++;
        sorolas.Add((int)szamok3[k]);
    }
}

Console.WriteLine($"Az elemek: {string.Join(",", szamok3)}");
Console.WriteLine($"A hárommal osztható generált számok: {oszthato}");
Console.WriteLine($"Ezek a számok oszthatóak 3-al:{string.Join(",", sorolas)}");
//adjuk az elemekhez az indexük 5x
int[] szam3 = new int[12];
for (int k = 0; k < szamok3.Length; k++)
{ szam3[k] = szamok3[k] + (k * 5); }
Console.WriteLine($"Az elemekhez adott indexüknek az 5x-se:{ string.Join(",", szam3)}");

Console.WriteLine("-------------------------------------------");
//legyen egy tömb amibe 8 random szám van 1-50 között, nézzük meg mennyi elem nagyobb, mint az átlag 
int[] szamok4 = new int[8];
Random rnd5 = new Random();
double nagyobbdb = 0;
int osszeg2 = 0;
double atlag2 = 0;
List<double> nagyobb2 = new List<double>();
for (int i = 0; i < szamok4.Length; i++)
{
    szamok4[i]= rnd5.Next(1, 51);
    osszeg2 += szamok4[i];
}
atlag2 = (double)osszeg2 / szamok4.Length;
Console.WriteLine($"Az elemek: {string.Join(",", szamok4)}");
Console.WriteLine($"Ennyi elem van: {szamok4.Length}");
Console.WriteLine($"Az elemek összege: {osszeg2}");
Console.WriteLine($"Az elemek átlaga:{atlag2:F2}");

for (int i=0; i<szamok4.Length; i++)
{
    if (szamok4[i] > atlag2)
    {
        nagyobbdb++;
        nagyobb2.Add((double)szamok4[i]);
    }
}
Console.WriteLine($"Ennyi elem nagyobb az átlagnál: {nagyobbdb}");
Console.WriteLine($"Az átlagnál nagyobb elemek: {string.Join(",", nagyobb2)}");

Console.WriteLine("-------------------------------------------");
int[] szamok5 = new int[20];
Random rnd6 = new Random();
int db = 0;
List<int> paratlan2 = new List<int>();
for (int i = 0; i < szamok5.Length; i++)
{
    szamok5[i] = rnd6.Next(1,1000);
    if (szamok5[i] % 2 == 1)
    {
        db++;
        paratlan2.Add(szamok5[i]); }
}
Console.WriteLine($"Az elemek: {string.Join(",", szamok5)}");
Console.WriteLine($"Ennyi páratlan elem van: {db}");
Console.WriteLine($"A páratlan elemek: {string.Join(",", paratlan2)}");



Console.ReadKey();
