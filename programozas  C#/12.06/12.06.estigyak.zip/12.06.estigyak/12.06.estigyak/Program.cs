﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Runtime.InteropServices.ComTypes;
using System.Text;
using System.Threading.Tasks;

namespace _12._06.estigyak
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Kepek();
           // Leghosszabb(Beker2(2));
            //Console.WriteLine($" Ennyi éves vagy:{Eletkor(2001)}");
           // Hackerirasmod();
            Jatek();
        }
        /*
        static string Beker()
        {   string fajlnev;
            int ponr;
            do
            {
                Console.WriteLine("Írja be a fáájlnevet a kiterjesztéssel: ");
                fajlnev = Console.ReadLine().ToLower();
                ponr = fajlnev.LastIndexOf('.');
            } while (fajlnev.Length - (ponr+1) !=3);
            return fajlnev;
        }

        static void Kepek()
        {
            string fajlnev = Beker();
            switch (fajlnev)
            { case "jpg": case "gif": case "png": Console.WriteLine("Kép típusú fájl");break;
                default: Console.WriteLine("Nem kép típusú fájl"); break; }
        }

        static string[] Beker2(int db)
        {   string fajl = "";
            string[] fajlok = new string[db];
            int pont;
            for (int i = 0; i < fajlok.Length; i++) {
                do
                {
                    Console.WriteLine($"Írja be a {i+1}. fájlnevet:");
                    fajl = Console.ReadLine().ToLower();
                    pont = fajl.LastIndexOf('.');

                } while (fajl.Length -(pont+1)!=3);
                fajlok[i] = fajl;
            }
            return fajlok;
        }

        static void Leghosszabb(string[] fajlok)
        {
            
            string max = "";
            for (int i = 0; i < fajlok.Length; i++)
            {
                
                if (fajlok[i].Length > max.Length)
                    max = fajlok[i];
            }
            Console.WriteLine($"A leghosszabb fájlnév: {max}");
        }
        static int Eletkor(int ev)
        {
            return 2025-ev;
        }

        static void Hackerirasmod()
        {   Console.WriteLine("Írja be a szöveget: ");
            string szoveg = Console.ReadLine().ToLower();
            char[] darabollt =szoveg.ToCharArray();
            for (int i = 0; i < darabollt.Length; i++)
            { switch (darabollt[i])
                    { case 'l': 
                        darabollt[i] = '1';break;
                    case 'o':
                        darabollt[i] = '0';break;
                    case 'e':
                        darabollt[i] = '3';break;
                    case 's':
                        darabollt[i] = '5';break;
                    case 'ó':
                        darabollt[i] = '6';break;
                    case 't':
                        darabollt[i] = '7';break;
                    case 'g':
                        darabollt[i] = '9';break;
                    }
            }
            Console.WriteLine(darabollt);
        }*/

        static char Beolvas3()
        {
            char beirt;
               do
                {
                    Console.WriteLine("Válasszon F vagy I között: ");
                    beirt = Convert.ToChar(Console.ReadLine().ToLower()[0]);
                } while (beirt != 'f' && beirt !='i');
            
            return beirt;
        }

        static void Jatek()
        { Random rnd = new Random();
            char[] v = new char[]{'f','i'};
            char gondol= v[rnd.Next(0, 2)]; ;
            char tipp;
            int probalkozas=0;
            for (int i = 0; i < v.Length; i++)
            {
                do {
                    gondol= v[rnd.Next(0, 2)];
                    Console.WriteLine("Gondoltam egy karatkterre....");
                    tipp = Beolvas3();
                    probalkozas++;
                } while (tipp!=gondol) ;
                
            }
            Eredmeny(probalkozas, gondol);
        }
        static void Eredmeny(int probalkozas, char gondol)
        {   Console.WriteLine($"Gratulálok {probalkozas} próbálkozásbol találta ki a {char.ToUpper( gondol)} gondolt karaktert");
        }
    }
}
